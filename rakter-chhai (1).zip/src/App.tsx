import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { HorrorBackground } from './components/HorrorBackground';
import { Footer } from './components/Footer';
import { Toaster } from 'sonner';
import { ThemeProvider } from './context/ThemeContext';

// Lazy load pages for better performance
const Home = lazy(() => import('./pages/Home'));
const StoryDetail = lazy(() => import('./pages/StoryDetail'));
const Editor = lazy(() => import('./pages/Editor'));
const Profile = lazy(() => import('./pages/Profile'));
const Admin = lazy(() => import('./pages/Admin'));
const Auth = lazy(() => import('./pages/Auth'));
const About = lazy(() => import('./pages/About'));
const Notifications = lazy(() => import('./pages/Notifications'));
const ReadingList = lazy(() => import('./pages/ReadingList'));
const FAQ = lazy(() => import('./pages/FAQ'));
const Contact = lazy(() => import('./pages/Contact'));
const Stories = lazy(() => import('./pages/Stories'));

export default function App() {
  return (
    <ThemeProvider>
      <Router>
      <div className="relative min-h-screen">
        <HorrorBackground />
        <Navbar />
        
        <main className="relative z-10">
          <Suspense fallback={
            <div className="flex h-[80vh] items-center justify-center">
              <div className="w-16 h-16 border-4 border-horror-red border-t-transparent rounded-full animate-spin"></div>
            </div>
          }>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/stories" element={<Stories />} />
              <Route path="/stories/:id" element={<StoryDetail />} />
              <Route path="/editor" element={<Editor />} />
              <Route path="/editor/:id" element={<Editor />} />
              <Route path="/profile/:id" element={<Profile />} />
              <Route path="/admin" element={<Admin />} />
              <Route path="/about" element={<About />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/reading-list" element={<ReadingList />} />
              <Route path="/faq" element={<FAQ />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/login" element={<Auth mode="login" />} />
              <Route path="/signup" element={<Auth mode="signup" />} />
            </Routes>
          </Suspense>
        </main>

        <Footer />
        <Toaster theme="dark" position="bottom-right" richColors />
      </div>
    </Router>
    </ThemeProvider>
  );
}
