import React, { createContext, useContext, useState, useEffect } from 'react';

interface ThemeContextType {
  isSoundEnabled: boolean;
  setIsSoundEnabled: (v: boolean) => void;
  brightness: number;
  setBrightness: (v: number) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isSoundEnabled, setIsSoundEnabled] = useState(false);
  const [brightness, setBrightness] = useState(100);

  // Persistence
  useEffect(() => {
    const saved = localStorage.getItem('horror-settings');
    if (saved) {
      const { sound, bright } = JSON.parse(saved);
      setIsSoundEnabled(sound);
      setBrightness(bright);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('horror-settings', JSON.stringify({ sound: isSoundEnabled, bright: brightness }));
  }, [isSoundEnabled, brightness]);

  return (
    <ThemeContext.Provider value={{ isSoundEnabled, setIsSoundEnabled, brightness, setBrightness }}>
      <div 
        style={{ filter: `brightness(${brightness}%)` }} 
        className="min-h-screen transition-[filter] duration-500"
      >
        {children}
      </div>
      
      {/* Background Ambience */}
      {isSoundEnabled && (
        <audio 
          autoPlay 
          loop 
          src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3" // Placeholder spooky sound
          className="hidden"
        />
      )}
    </ThemeContext.Provider>
  );
};

export const useThemeSettings = () => {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useThemeSettings must be used within ThemeProvider');
  return context;
};
