import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { db, auth } from '../lib/firebase';
import { 
  doc, getDoc, collection, query, orderBy, onSnapshot, addDoc, 
  serverTimestamp, updateDoc, increment, deleteDoc, where, getDocs, setDoc, limit
} from 'firebase/firestore';
import { useAuth } from '../hooks/useAuth';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Ghost, MessageSquare, Share2, Heart, Eye,
  MoreVertical, Reply, Trash2, ShieldAlert, Bookmark, ShieldCheck, Clock, Settings, Type, ArrowUp
} from 'lucide-react';

const calculateReadingTime = (content: string) => {
  const wordsPerMinute = 200;
  const words = content.split(/\s+/g).length;
  const minutes = Math.ceil(words / wordsPerMinute);
  return minutes;
};
import ReactMarkdown from 'react-markdown';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';

const StoryDetail: React.FC = () => {
  const { id } = useParams();
  const { user, profile } = useAuth();
  const [story, setStory] = useState<any>(null);
  const [comments, setComments] = useState<any[]>([]);
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [loading, setLoading] = useState(true);
  const [isSaved, setIsSaved] = useState(false);
  const [hasLiked, setHasLiked] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [fontSize, setFontSize] = useState(18);
  const [showSettings, setShowSettings] = useState(false);
  const [guestName, setGuestName] = useState('অজ্ঞাত আত্মা');

  // Captcha for comments
  const [captchaText, setCaptchaText] = useState(() => Math.random().toString(36).substring(2, 5).toUpperCase());
  const [captchaInput, setCaptchaInput] = useState('');

  const getGuestId = () => {
    let gid = localStorage.getItem('horror_guest_id');
    if (!gid) {
      gid = 'guest_' + Math.random().toString(36).substring(2, 11);
      localStorage.setItem('horror_guest_id', gid);
    }
    return gid;
  };

  useEffect(() => {
    if (!id) return;

    const currentUserId = user?.uid || getGuestId();

    // Check if saved
    if (user) {
      const q = query(collection(db, 'readingLists'), where('userId', '==', user.uid), where('storyId', '==', id));
      getDocs(q).then(snap => setIsSaved(!snap.empty));
    }

    // Check if liked
    const checkLike = async () => {
      const likeRef = doc(db, 'interactions', `like_${currentUserId}_${id}`);
      const likeSnap = await getDoc(likeRef);
      setHasLiked(likeSnap.exists());
    };
    checkLike();

    // Scroll progress listener
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = (window.scrollY / totalHeight) * 100;
      setScrollProgress(progress);
    };
    window.addEventListener('scroll', handleScroll);

    // Fetch Story & Unique View
    const fetchStory = async () => {
      const docRef = doc(db, 'stories', id);
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        const data = snap.data();
        if (data.status !== 'published' && data.authorId !== user?.uid && profile?.role !== 'admin') {
          toast.error("This story is hidden in the shadows.");
          return;
        }
        setStory({ id: snap.id, ...data });
        
        // --- Unique View Logic ---
        const viewId = `view_${currentUserId}_${id}`;
        const viewRef = doc(db, 'interactions', viewId);
        const viewSnap = await getDoc(viewRef);
        
        if (!viewSnap.exists()) {
          try {
            await setDoc(viewRef, {
              userId: currentUserId,
              storyId: id,
              type: 'view',
              createdAt: serverTimestamp()
            });

            // Increment view count on story
            await updateDoc(docRef, { viewCount: increment(1) });
            
            // Update author stats
            if (data.authorId !== 'guest') {
              const authorRef = doc(db, 'users', data.authorId);
              const authorSnap = await getDoc(authorRef);
              if (authorSnap.exists()) {
                const authorData = authorSnap.data();
                const updates: any = { totalViews: increment(1) };
                if (authorData.isMonetized) {
                  // 0.5 TK per view
                  updates.earnings = increment(0.5);
                }
                await updateDoc(authorRef, updates);
              }
            }
          } catch (e) {
            console.error("View tracking failed:", e);
          }
        }
      }
      setLoading(false);
    };

    fetchStory();

    // Real-time Comments
    const commentsRef = collection(db, 'stories', id, 'comments');
    const q = query(commentsRef, orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snap) => {
      setComments(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    return () => {
      unsubscribe();
      window.removeEventListener('scroll', handleScroll);
    };
  }, [id, user, profile]);

  const handleLike = async () => {
    if (!id) return;
    const currentUserId = user?.uid || getGuestId();
    const likeRef = doc(db, 'interactions', `like_${currentUserId}_${id}`);

    try {
      if (hasLiked) {
        // Unlike
        await deleteDoc(likeRef);
        await updateDoc(doc(db, 'stories', id), { likeCount: increment(-1) });
        setHasLiked(false);
        setStory((prev: any) => ({ ...prev, likeCount: (prev.likeCount || 1) - 1 }));
        toast.info('পছন্দ তুলে নেওয়া হয়েছে।');
      } else {
        // Like
        await setDoc(likeRef, {
          userId: currentUserId,
          storyId: id,
          type: 'like',
          createdAt: serverTimestamp()
        });
        await updateDoc(doc(db, 'stories', id), { likeCount: increment(1) });
        setHasLiked(true);
        setStory((prev: any) => ({ ...prev, likeCount: (prev.likeCount || 0) + 1 }));

        // Notify Author of Like
        if (story.authorId !== currentUserId) {
          await addDoc(collection(db, 'notifications'), {
            userId: story.authorId,
            type: 'like',
            actorId: currentUserId,
            actorName: profile?.displayName || user?.displayName || guestName || 'কেউ একজন',
            resourceId: id,
            isRead: false,
            createdAt: serverTimestamp(),
          });
        }
        
        toast.success('আপনি গল্পটি পছন্দ করেছেন।', { icon: '❤️' });
      }
    } catch (error) {
      toast.error('Unable to react right now.');
    }
  };

  const handleBookmark = async () => {
    if (!user) {
      toast.error('সেভ করতে লগইন করুন।');
      return;
    }
    try {
      if (isSaved) {
        const q = query(collection(db, 'readingLists'), where('userId', '==', user.uid), where('storyId', '==', id));
        const snap = await getDocs(q);
        snap.forEach(async (d) => await deleteDoc(doc(db, 'readingLists', d.id)));
        setIsSaved(false);
        toast.info('পঠন তালিকা থেকে মুছে ফেলা হয়েছে।');
      } else {
        await addDoc(collection(db, 'readingLists'), {
          userId: user.uid,
          storyId: id,
          createdAt: serverTimestamp(),
        });
        setIsSaved(true);
        toast.success('পঠন তালিকায় সংরক্ষণ করা হয়েছে।');
      }
    } catch (err) {
      toast.error('ব্যর্থ হয়েছে।');
    }
  };

  const submitComment = async (e: React.FormEvent, parentId: string | null = null) => {
    e.preventDefault();
    
    if (!parentId && captchaInput.toUpperCase() !== captchaText) {
      toast.error('ভুল ক্যাপচা কোড!');
      return;
    }

    const content = parentId ? replyContent : newComment;
    if (!content.trim()) return;

    try {
      const authorId = user?.uid || 'guest';
      const authorName = profile?.displayName || user?.displayName || guestName || 'অজানা আত্মা';
      const authorPhoto = profile?.photoURL || user?.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${authorName}`;

      await addDoc(collection(db, 'stories', id!, 'comments'), {
        content,
        authorId,
        authorName,
        authorPhoto,
        storyId: id,
        parentId,
        createdAt: serverTimestamp(),
      });

      // Update story comment count
      await updateDoc(doc(db, 'stories', id!), {
        commentCount: increment(1)
      });
      
      // Notify Author
      if (story.authorId !== authorId) {
        await addDoc(collection(db, 'notifications'), {
          userId: story.authorId,
          type: parentId ? 'reply' : 'comment',
          actorId: authorId,
          actorName: authorName,
          resourceId: id,
          isRead: false,
          createdAt: serverTimestamp(),
        });
      }

      // If it's a reply, notify the parent comment author too if they are not the story author
      if (parentId) {
        const parentComment = comments.find(c => c.id === parentId);
        if (parentComment && parentComment.authorId !== authorId && parentComment.authorId !== story.authorId && parentComment.authorId !== 'guest') {
          await addDoc(collection(db, 'notifications'), {
            userId: parentComment.authorId,
            type: 'reply',
            actorId: authorId,
            actorName: authorName,
            resourceId: id,
            isRead: false,
            createdAt: serverTimestamp(),
          });
        }
      }

      if (parentId) {
        setReplyingTo(null);
        setReplyContent('');
      } else {
        setNewComment('');
      }
      toast.success('মন্তব্য সফল হয়েছে।');
    } catch (error) {
      toast.error('Comment failed.');
    }
  };

  if (loading) return <LoadingSpinner />;
  if (!story) return <div className="text-center py-20 grayscale opacity-50"><Ghost className="mx-auto mb-4 animate-bounce" /> গল্পটি কুয়াশার আড়ালে হারিয়ে গেছে...</div>;

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: story.title,
        text: `রক্তের ছাই - ${story.title}`,
        url: window.location.href,
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success('লিঙ্কটি কপি করা হয়েছে।');
    }
  };

  return (
    <>
      {/* Reading Progress Bar */}
      <div className="fixed top-0 left-0 w-full h-1 z-[60] bg-transparent">
        <motion.div 
          className="h-full bg-horror-red shadow-[0_0_10px_#ff0000]"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      {/* Floating Actions */}
      <div className="fixed bottom-32 right-4 md:right-8 flex flex-col gap-4 z-40">
        <AnimatePresence>
          {scrollProgress > 20 && (
            <motion.button
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.5 }}
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="p-3 bg-horror-charcoal/80 backdrop-blur border border-horror-gray rounded-full text-horror-red shadow-xl hover:bg-horror-red hover:text-white transition-all"
            >
              <ArrowUp size={20} />
            </motion.button>
          )}
        </AnimatePresence>
        
        <div className="relative">
          <button 
            onClick={() => setShowSettings(!showSettings)}
            className="p-3 bg-horror-charcoal/80 backdrop-blur border border-horror-gray rounded-full text-gray-400 shadow-xl hover:text-horror-red transition-all"
          >
            <Settings size={20} />
          </button>
          
          <AnimatePresence>
            {showSettings && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="absolute bottom-0 right-14 bg-horror-charcoal border border-horror-gray p-4 rounded-lg shadow-2xl w-40"
              >
                <p className="text-[10px] uppercase text-gray-500 mb-3 flex items-center gap-2">
                  <Type size={12} /> ফন্ট সাইজ
                </p>
                <div className="flex items-center justify-between gap-4">
                  <button onClick={() => setFontSize(Math.max(14, fontSize - 2))} className="p-1 hover:text-horror-red text-lg">-</button>
                  <span className="text-sm font-mono">{fontSize}px</span>
                  <button onClick={() => setFontSize(Math.min(28, fontSize + 2))} className="p-1 hover:text-horror-red text-lg">+</button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <article className="max-w-4xl mx-auto px-4 py-12">
      {/* Story Header */}
      <header className="mb-12">
        <div className="flex items-center gap-4 mb-6">
          <Link to={`/profile/${story.authorId}`} className="flex items-center gap-2 group">
            <img src={story.authorPhoto || `https://api.dicebear.com/7.x/avataaars/svg?seed=${story.authorId}`} className="w-12 h-12 rounded-full border-2 border-horror-gray group-hover:border-horror-red transition-all" alt={story.authorName} />
            <div>
              <p className="font-bold group-hover:text-horror-red transition-colors">{story.authorName}</p>
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <span>{story.createdAt ? formatDistanceToNow(story.createdAt.toDate()) : ''} ago</span>
                <span>•</span>
                <span className="flex items-center gap-1"><Clock size={12} /> {calculateReadingTime(story.content)} মিনিট পাঠ</span>
              </div>
            </div>
          </Link>
        </div>

        <h1 className="horror-title text-4xl md:text-6xl text-horror-red mb-4 leading-tight">{story.title}</h1>
        
        <div className="flex items-center gap-6 mb-8 text-sm text-gray-400 font-mono">
          <div className="flex items-center gap-2">
            <Eye size={18} className="text-horror-red" />
            <span>{story.viewCount || 0} ভিউ</span>
          </div>
          <div className="flex items-center gap-2">
            <Heart size={18} className="text-horror-red" />
            <span>{story.likeCount || 0} লাইক</span>
          </div>
          <div className="flex items-center gap-2">
            <MessageSquare size={18} className="text-horror-red" />
            <span>{comments.length} মন্তব্য</span>
          </div>
        </div>
        
        {story.coverImage && (
          <div className="relative h-[400px] rounded-xl overflow-hidden mb-12 border border-horror-gray">
            <img src={story.coverImage} className="w-full h-full object-cover opacity-80" alt={story.title} />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
          </div>
        )}
      </header>

      {/* Story content */}
      <div 
        className="prose prose-invert prose-red max-w-none mb-20 font-serif leading-relaxed text-gray-300 selection:bg-horror-red selection:text-white"
        style={{ fontSize: `${fontSize}px` }}
      >
        <ReactMarkdown>{story.content}</ReactMarkdown>
      </div>

      {/* Interactions */}
      <div className="sticky bottom-8 left-0 right-0 flex justify-center pointer-events-none z-50">
        <div className="bg-horror-charcoal/90 backdrop-blur-xl border border-horror-gray/50 rounded-full px-8 py-4 flex items-center gap-10 shadow-[0_0_50px_rgba(0,0,0,0.8)] pointer-events-auto">
          <button onClick={handleLike} className={`flex items-center gap-2 transition-all group ${hasLiked ? 'text-horror-red scale-110' : 'text-gray-400 hover:text-horror-red'}`}>
            <Heart className={`w-6 h-6 group-active:scale-125 transition-transform ${hasLiked ? 'fill-current' : ''}`} />
            <span className="font-mono text-sm font-bold">{story.likeCount || 0}</span>
          </button>
          <div className="flex items-center gap-2 text-gray-400">
            <MessageSquare className="w-6 h-6" />
            <span className="font-mono text-sm font-bold">{comments.length}</span>
          </div>
          <button onClick={handleBookmark} className={`transition-all ${isSaved ? 'text-horror-red scale-110' : 'text-gray-400 hover:text-horror-red'}`}>
            <Bookmark className="w-6 h-6" fill={isSaved ? "currentColor" : "none"} />
          </button>
          <div className="w-[1px] h-6 bg-horror-gray/30" />
          <button onClick={handleShare} className="text-gray-400 hover:text-horror-red transition-all">
            <Share2 className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Related Stories */}
      <section className="mt-20 py-12 border-t border-horror-gray">
        <h2 className="horror-title text-2xl mb-8 uppercase tracking-widest flex items-center gap-3">
          <Ghost className="text-horror-red" /> আরো কিছু অন্ধকার কাহিনী
        </h2>
        <RelatedStories category={story.category} currentStoryId={story.id} />
      </section>

      {/* Stories Section Anchor for Comments */}
      <section id="comments" className="pt-12 border-t border-horror-gray">
        <h2 className="horror-title text-2xl mb-8 uppercase tracking-widest">মন্তব্যসমূহ</h2>

        <form onSubmit={(e) => submitComment(e)} className="mb-12">
          <div className="flex gap-4">
            <img src={profile?.photoURL || user?.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.uid || guestName}`} className="w-10 h-10 rounded-full" />
            <div className="flex-1 space-y-3">
              {!user && (
                 <input 
                   type="text" 
                   placeholder="আপনার নাম (Guest Name)" 
                   className="horror-input py-2 text-xs border-b border-horror-gray rounded-none"
                   value={guestName}
                   onChange={(e) => setGuestName(e.target.value)}
                 />
              )}
              <textarea 
                placeholder="আপনার মতামত জানান..." 
                className="horror-input min-h-[100px] resize-none"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
              />
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 bg-black/50 p-2 rounded border border-horror-gray">
                  <span className="text-horror-red font-mono font-bold tracking-tighter line-through decoration-white/30 italic">{captchaText}</span>
                  <input 
                    type="text" 
                    placeholder="কোড" 
                    className="w-16 bg-transparent outline-none text-xs text-white border-l border-horror-gray pl-2"
                    value={captchaInput}
                    onChange={(e) => setCaptchaInput(e.target.value)}
                  />
                </div>
                <button type="submit" className="horror-btn py-1 text-sm">মন্তব্য করুন</button>
              </div>
            </div>
          </div>
        </form>

        <div className="space-y-8">
          {comments.filter(c => !c.parentId).map(comment => (
            <CommentItem 
              key={comment.id} 
              comment={comment} 
              replies={comments.filter(c => c.parentId === comment.id)}
              onReply={(id) => setReplyingTo(id)}
              replyingTo={replyingTo}
              replyContent={replyContent}
              setReplyContent={setReplyContent}
              submitReply={(e) => submitComment(e, comment.id)}
              isOwner={user?.uid === comment.authorId || profile?.role === 'admin'}
              storyId={id!}
            />
          ))}
        </div>
      </section>
    </article>
    </>
  );
};

const RelatedStories = ({ category, currentStoryId }: { category: string, currentStoryId: string }) => {
  const [stories, setStories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRelated = async () => {
      try {
        const q = query(
          collection(db, 'stories'), 
          where('category', '==', category),
          where('status', '==', 'published'),
          limit(4)
        );
        const snap = await getDocs(q);
        const filtered = snap.docs
          .map(doc => ({ id: doc.id, ...doc.data() }))
          .filter(s => s.id !== currentStoryId)
          .slice(0, 3);
        setStories(filtered);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchRelated();
  }, [category, currentStoryId]);

  if (loading) return <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-pulse">
    {[1, 2, 3].map(i => <div key={i} className="h-40 bg-horror-gray/20 rounded"></div>)}
  </div>;

  if (stories.length === 0) return <p className="text-gray-500 italic">এই বিভাগে অন্য আর কোনো গল্প নেই...</p>;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {stories.map(s => (
        <Link key={s.id} to={`/stories/${s.id}`} className="horror-card group flex flex-col p-0 overflow-hidden border-horror-gray/30">
          <div className="h-32 overflow-hidden bg-horror-black">
            <img 
              src={s.coverImage || "https://images.unsplash.com/photo-1509248961158-e54f6934749c?auto=format&fit=crop&q=80&w=400"} 
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 opacity-60 group-hover:opacity-100" 
              alt={s.title}
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="p-4">
            <h3 className="font-bold text-sm mb-2 group-hover:text-horror-red transition-colors line-clamp-1">{s.title}</h3>
            <div className="flex items-center justify-between text-[10px] text-gray-500 font-mono">
              <span className="flex items-center gap-1"><Eye size={12} /> {s.viewCount || 0}</span>
              <span className="flex items-center gap-1"><Heart size={12} /> {s.likeCount || 0}</span>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
};

const CommentItem = ({ comment, replies, onReply, replyingTo, replyContent, setReplyContent, submitReply, isOwner, storyId }: any) => {
  const handleDelete = async () => {
    if (window.confirm('Delete this comment from the shadows?')) {
      try {
        await deleteDoc(doc(db, 'stories', storyId, 'comments', comment.id));
        toast.success('Comment banished.');
      } catch (err) {
        toast.error('Deletion failed.');
      }
    }
  };

  return (
    <div className="group">
      <div className="flex gap-4">
        <img src={comment.authorPhoto || `https://api.dicebear.com/7.x/avataaars/svg?seed=${comment.authorId}`} className="w-10 h-10 rounded-full border border-horror-gray" />
        <div className="flex-1">
          <div className="bg-horror-charcoal/50 p-4 rounded-lg border border-horror-gray group-hover:border-horror-red/20 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-sm">{comment.authorName}</span>
              <div className="flex items-center gap-3">
                <span className="text-[10px] text-gray-500 italic">{comment.createdAt ? formatDistanceToNow(comment.createdAt.toDate()) : ''} ago</span>
                {isOwner && (
                  <button onClick={handleDelete} className="text-gray-600 hover:text-horror-red transition-colors">
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">{comment.content}</p>
          </div>
          
          <div className="flex items-center gap-4 mt-2 ml-2">
            <button 
              onClick={() => onReply(comment.id)} 
              className="flex items-center gap-1 text-[10px] uppercase text-gray-500 hover:text-horror-red transition-all"
            >
              <Reply size={12} /> উত্তর দিন
            </button>
          </div>

          <AnimatePresence>
            {replyingTo === comment.id && (
              <motion.form 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                onSubmit={submitReply}
                className="mt-4 ml-4"
              >
                <textarea 
                  autoFocus
                  placeholder="আপনার উত্তর লিখুন..." 
                  className="horror-input text-sm min-h-[80px] mb-2"
                  value={replyContent}
                  onChange={(e) => setReplyContent(e.target.value)}
                />
                <div className="flex justify-end gap-2">
                  <button type="button" onClick={() => onReply(null)} className="text-xs text-gray-500 px-3">বাতিল</button>
                  <button type="submit" className="horror-btn py-1 px-3 text-xs">উত্তর পাঠান</button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          {/* Nested Replies */}
          {replies.length > 0 && (
            <div className="mt-6 ml-10 space-y-6 border-l border-horror-gray pl-6">
              {replies.map((reply: any) => (
                <div key={reply.id} className="flex gap-3">
                  <img src={reply.authorPhoto || `https://api.dicebear.com/7.x/avataaars/svg?seed=${reply.authorId}`} className="w-8 h-8 rounded-full border border-horror-gray" />
                  <div className="flex-1 bg-horror-black p-3 rounded-lg border border-horror-gray">
                    <div className="flex items-center justify-between mb-1">
                       <span className="font-bold text-xs">{reply.authorName}</span>
                       <span className="text-[9px] text-gray-500 italic">{reply.createdAt ? formatDistanceToNow(reply.createdAt.toDate()) : ''} ago</span>
                    </div>
                    <p className="text-gray-400 text-xs">{reply.content}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const LoadingSpinner = () => (
  <div className="flex flex-col items-center justify-center h-screen gap-4">
    <div className="relative w-16 h-16">
      <motion.div 
        animate={{ rotate: 360, scale: [1, 1.2, 1] }} 
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute inset-0 border-t-2 border-horror-red rounded-full"
      />
      <Ghost className="absolute inset-4 text-horror-red animate-pulse" />
    </div>
    <span className="horror-title text-horror-red animate-pulse">অন্ধকার পথ খুঁজে দেখা হচ্ছে...</span>
  </div>
);

export default StoryDetail;
