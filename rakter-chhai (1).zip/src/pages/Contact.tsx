import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, Send, MapPin, Phone } from 'lucide-react';
import { toast } from 'sonner';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('আপনার বার্তা নরকে... মানে আমাদের টিমের কাছে পৌঁছেছে!');
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-20">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
        <div className="space-y-8">
          <div>
            <h1 className="horror-title text-5xl text-horror-red mb-4">যোগাযোগ</h1>
            <p className="text-gray-400 italic">"আমাদের কাছে আপনার কোনো অভিযোগ বা পরামর্শ থাকলে নির্ভয়ে জানান।"</p>
          </div>

          <div className="space-y-6">
            <div className="flex gap-4 items-center">
              <div className="p-4 bg-horror-charcoal rounded-lg text-horror-red"><Mail /></div>
              <div>
                <p className="text-xs uppercase text-gray-500">ইমেল</p>
                <p className="text-lg">astbangla2024@gmail.com</p>
              </div>
            </div>
            <div className="flex gap-4 items-center">
              <div className="p-4 bg-horror-charcoal rounded-lg text-horror-red"><MapPin /></div>
              <div>
                <p className="text-xs uppercase text-gray-500">অফিস</p>
                <p className="text-lg">অন্ধকার গলি, বনানী, ঢাকা</p>
              </div>
            </div>
          </div>
        </div>

        <motion.form 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleSubmit}
          className="horror-card p-8 space-y-6"
        >
          <div className="space-y-2">
            <label className="text-xs uppercase text-gray-500">নাম</label>
            <input 
              type="text" 
              required
              className="horror-input" 
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs uppercase text-gray-500">ইমেল</label>
            <input 
              type="email" 
              required
              className="horror-input" 
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs uppercase text-gray-500">বার্তা</label>
            <textarea 
              required
              className="horror-input min-h-[150px]" 
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
            />
          </div>
          <button type="submit" className="horror-btn w-full flex items-center justify-center gap-2">
            <Send size={18} /> বার্তা পাঠান
          </button>
        </motion.form>
      </div>
    </div>
  );
};

export default Contact;
