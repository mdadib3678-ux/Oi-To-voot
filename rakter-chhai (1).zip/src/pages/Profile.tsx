import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { db, auth } from '../lib/firebase';
import { 
  doc, getDoc, collection, query, where, getDocs, 
  updateDoc, increment, serverTimestamp, setDoc, deleteDoc 
} from 'firebase/firestore';
import { useAuth } from '../hooks/useAuth';
import { motion } from 'motion/react';
import { 
  User, Settings, Edit3, Heart, Eye, MessageSquare,
  UserPlus, UserMinus, Award, BookOpen, AlertCircle, Trash2
} from 'lucide-react';
import { toast } from 'sonner';

const Profile: React.FC = () => {
  const { id } = useParams();
  const { user: currentUser, profile: currentProfile } = useAuth();
  const navigate = useNavigate();
  
  const [profile, setProfile] = useState<any>(null);
  const [stories, setStories] = useState<any[]>([]);
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'stories' | 'monetization'>('stories');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAppModalOpen, setIsAppModalOpen] = useState(false);
  
  const [editData, setEditData] = useState({ displayName: '', bio: '', photoURL: '' });
  const [appData, setAppData] = useState({ fullName: '', age: '', bkash: '' });

  const isOwnProfile = currentUser?.uid === id;

  useEffect(() => {
    if (!id) return;

    const fetchProfile = async () => {
      setLoading(true);
      try {
        const userDoc = await getDoc(doc(db, 'users', id));
        if (userDoc.exists()) {
          const data = userDoc.data();
          setProfile({ id: userDoc.id, ...data });
          setEditData({ 
            displayName: data.displayName || '', 
            bio: data.bio || '', 
            photoURL: data.photoURL || '' 
          });
        } else {
          toast.error('The spirit of this user cannot be found.');
          navigate('/');
        }

        // Stories
        let storiesRef = collection(db, 'stories');
        let storiesQ;
        
        if (isOwnProfile) {
          // Show all stories for owner (drafts, pending, published)
          storiesQ = query(storiesRef, where('authorId', '==', id));
        } else {
          // Show only published stories for others
          storiesQ = query(storiesRef, where('authorId', '==', id), where('status', '==', 'published'));
        }
        
        const storiesSnap = await getDocs(storiesQ);
        const storiesData = storiesSnap.docs.map(doc => {
          const data = doc.data() as any;
          return { id: doc.id, ...data };
        });
        setStories(storiesData.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0)));

        // Check Following
        if (currentUser && !isOwnProfile) {
          const followId = `${currentUser.uid}_${id}`;
          const followSnap = await getDoc(doc(db, 'follows', followId));
          setIsFollowing(followSnap.exists());
        }
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [id, currentUser, isOwnProfile, navigate]);

  const handleFollow = async () => {
    if (!currentUser) {
      toast.error('Login to follow this author.');
      return;
    }
    const followId = `${currentUser.uid}_${id}`;
    try {
      if (isFollowing) {
        await deleteDoc(doc(db, 'follows', followId));
        await updateDoc(doc(db, 'users', id!), { followerCount: increment(-1) });
        await updateDoc(doc(db, 'users', currentUser.uid), { followingCount: increment(-1) });
        setIsFollowing(false);
        toast.success(`You unfollowed ${profile?.displayName}.`);
      } else {
        await setDoc(doc(db, 'follows', followId), {
          followerId: currentUser.uid,
          followingId: id,
          createdAt: serverTimestamp()
        });
        await updateDoc(doc(db, 'users', id!), { followerCount: increment(1) });
        await updateDoc(doc(db, 'users', currentUser.uid), { followingCount: increment(1) });
        
        // Notify
        await setDoc(doc(collection(db, 'notifications')), {
          userId: id,
          type: 'follow',
          actorId: currentUser.uid,
          actorName: currentProfile?.displayName || 'অজানা আত্মা',
          createdAt: serverTimestamp(),
          isRead: false
        });

        setIsFollowing(true);
        toast.success(`You are now following ${profile?.displayName}.`);
      }
    } catch (error) {
      toast.error('Follow operation failed.');
    }
  };

  const applyMonetization = async () => {
    if (profile.followerCount < 250 || profile.totalViews < 1000) {
      toast.error('যোগ্য হতে আরও ফলোয়ার এবং পাঠক প্রয়োজন।');
      return;
    }
    setIsAppModalOpen(true);
  };

  const submitApplication = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateDoc(doc(db, 'users', currentUser!.uid), {
        monetizationStatus: 'pending',
        monetizationDetails: {
          fullName: appData.fullName,
          age: appData.age,
          bkash: appData.bkash,
          appliedAt: new Date()
        }
      });
      
      // Notify Admins
      await setDoc(doc(collection(db, 'notifications')), {
        userId: 'admin', // System notification for admins or targeted
        type: 'monetization_request',
        actorId: currentUser!.uid,
        actorName: profile.displayName,
        createdAt: serverTimestamp(),
        isRead: false
      });

      setProfile({ ...profile, monetizationStatus: 'pending' });
      setIsAppModalOpen(false);
      toast.success('আপনার আবেদন পাঠানো হয়েছে। অ্যাডমিন টিম দ্রুত যোগাযোগ করবে।');
    } catch (err) {
      toast.error('আবেদন ব্যর্থ হয়েছে।');
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateDoc(doc(db, 'users', currentUser!.uid), {
        displayName: editData.displayName,
        bio: editData.bio,
        photoURL: editData.photoURL
      });
      setProfile({ ...profile, ...editData });
      setIsEditModalOpen(false);
      toast.success('প্রোফাইল আপডেট করা হয়েছে।');
    } catch (err) {
      toast.error('আপডেট ব্যর্থ হয়েছে।');
    }
  };

  const triggerWithdrawal = async () => {
    try {
      await setDoc(doc(collection(db, 'notifications')), {
        userId: 'admin',
        type: 'withdrawal_request',
        actorId: currentUser!.uid,
        actorName: profile.displayName,
        message: `${profile.displayName} ১০০০ টাকা উপার্জনের সীমা অতিক্রম করেছেন। বিকাশ নম্বর: ${profile.monetizationDetails?.bkash || 'N/A'}`,
        createdAt: serverTimestamp(),
        isRead: false
      });
      toast.success('অ্যাডমিনকে জানানো হয়েছে। দ্রুত আপনার সাথে যোগাযোগ করা হবে।');
    } catch (err) {
      toast.error('ব্যর্থ হয়েছে।');
    }
  };

  const handleDeleteStory = async (e: React.MouseEvent, storyId: string) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (window.confirm('আপনি কি নিশ্চিত যে আপনি এই গল্পটি মুছে ফেলতে চান?')) {
      try {
        await deleteDoc(doc(db, 'stories', storyId));
        setStories(stories.filter(s => s.id !== storyId));
        toast.success('গল্পটি মুছে ফেলা হয়েছে।');
      } catch (err) {
        toast.error('মুছে ফেলতে সমস্যা হয়েছে।');
      }
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-12 h-12 border-4 border-horror-red border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      {/* Profile Header */}
      <div className="horror-card p-8 mb-12 flex flex-col md:flex-row items-center gap-12">
        <div className="relative">
          <img 
            src={profile.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${id}`} 
            className="w-40 h-40 rounded-full border-4 border-horror-gray shadow-[0_0_30px_rgba(139,0,0,0.3)]" 
            alt={profile.displayName}
          />
          {profile.isMonetized && (
            <div className="absolute bottom-2 right-2 bg-yellow-500 text-black p-1 rounded-full border-2 border-horror-black shadow-lg" title="Monetized Artist">
              <Award size={20} />
            </div>
          )}
        </div>

        <div className="flex-1 text-center md:text-left space-y-4">
          <div>
            <h1 className="horror-title text-4xl mb-2">{profile.displayName}</h1>
            <p className="text-gray-400 italic max-w-xl">{profile.bio || "এই লেখকের সম্পর্কে কিছু জানা নেই... এখনো।"}</p>
          </div>

          <div className="flex flex-wrap justify-center md:justify-start gap-8">
            <div className="text-center">
              <p className="text-2xl font-bold text-horror-red">{profile.followerCount || 0}</p>
              <p className="text-[10px] uppercase tracking-widest text-gray-500">অনুগামী</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-horror-red">{profile.followingCount || 0}</p>
              <p className="text-[10px] uppercase tracking-widest text-gray-500">অনুসরণ</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-horror-red">{profile.totalViews || 0}</p>
              <p className="text-[10px] uppercase tracking-widest text-gray-500">মোট পাঠ</p>
            </div>
          </div>

          <div className="flex flex-wrap justify-center md:justify-start gap-4 pt-4">
            {isOwnProfile ? (
              <>
                <button onClick={() => setIsEditModalOpen(true)} className="px-4 py-2 border border-horror-gray rounded hover:bg-horror-gray transition-all">
                  প্রোফাইল এডিট
                </button>
                <button onClick={() => navigate('/editor')} className="horror-btn flex items-center gap-2">
                  <Edit3 size={18} /> লিখুন
                </button>
              </>
            ) : (
              <button 
                onClick={handleFollow}
                className={`px-8 py-2 rounded-full flex items-center gap-2 transition-all ${isFollowing ? 'border border-horror-gray hover:text-horror-red' : 'horror-btn'}`}
              >
                {isFollowing ? <><UserMinus size={18} /> অনুসরণ করা বন্ধ করুন</> : <><UserPlus size={18} /> অনুসরণ করুন</>}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-horror-gray mb-8">
        <button 
          onClick={() => setTab('stories')} 
          className={`px-8 py-4 text-xs uppercase tracking-[0.2em] font-bold transition-all relative ${tab === 'stories' ? 'text-horror-red' : 'text-gray-500'}`}
        >
          গল্প সমূহ
          {tab === 'stories' && <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-horror-red" />}
        </button>
        {isOwnProfile && (
          <button 
            onClick={() => setTab('monetization')} 
            className={`px-8 py-4 text-xs uppercase tracking-[0.2em] font-bold transition-all relative ${tab === 'monetization' ? 'text-horror-red' : 'text-gray-500'}`}
          >
            উপার্জন
            {tab === 'monetization' && <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-horror-red" />}
          </button>
        )}
      </div>

      {/* Tab Content */}
      <div className="min-h-[40vh]">
        {tab === 'stories' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {stories.map(story => (
              <div key={story.id} className="relative group">
                <Link to={`/stories/${story.id}`}>
                  <div className="horror-card h-full">
                    <div className="overflow-hidden relative">
                      {story.coverImage && (
                        <div className="h-40 overflow-hidden">
                          <img src={story.coverImage} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 opacity-60" />
                        </div>
                      )}
                      <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-horror-charcoal to-transparent" />
                      {isOwnProfile && (
                        <div className="absolute top-2 left-2 flex gap-2">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-tighter ${
                            story.status === 'published' ? 'bg-green-600' : 
                            story.status === 'pending' ? 'bg-yellow-600' : 'bg-gray-600'
                          }`}>
                            {story.status === 'published' ? 'পাবলিশড' : story.status === 'pending' ? 'পেন্ডিং' : 'ড্রাফট'}
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="font-serif font-bold text-lg group-hover:text-horror-red transition-colors mb-2 line-clamp-1">{story.title}</h3>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3 text-[10px] text-gray-500">
                          <span className="flex items-center gap-1"><Eye size={12} className="text-horror-red/70" /> {story.viewCount || 0}</span>
                          <span className="flex items-center gap-1"><Heart size={12} className="text-horror-red/70" /> {story.likeCount || 0}</span>
                          <span className="flex items-center gap-1"><MessageSquare size={12} className="text-horror-red/70" /> {story.commentCount || 0}</span>
                        </div>
                        {isOwnProfile && (
                          <div className="flex gap-1">
                            <button 
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                navigate(`/editor?id=${story.id}`);
                              }}
                              className="p-1.5 bg-horror-gray rounded hover:text-horror-red transition-all"
                              title="সম্পাদনা করুন"
                            >
                              <Edit3 size={14} />
                            </button>
                            <button 
                              onClick={(e) => handleDeleteStory(e, story.id)}
                              className="p-1.5 bg-horror-gray rounded hover:text-horror-red transition-all"
                              title="মুছে ফেলুন"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
            {stories.length === 0 && <p className="col-span-full pt-10 text-center text-gray-500 italic">কোনো গল্প পাওয়া যায়নি...</p>}
          </div>
        )}

        {tab === 'monetization' && (
          <div className="max-w-2xl mx-auto space-y-8">
            <div className="horror-card p-8">
              <h3 className="horror-title text-2xl mb-6 flex items-center gap-2">
                <Award className="text-yellow-500" /> উপার্জনের অগ্রগতি
              </h3>
              
              <div className="space-y-8">
                {/* Followers Progress */}
                <div>
                  <div className="flex justify-between text-xs mb-2">
                    <span className="text-gray-400 uppercase tracking-widest">অনুগামী (২৫০ প্রয়োজন)</span>
                    <span className="text-horror-red font-mono">{profile.followerCount} / 250</span>
                  </div>
                  <div className="h-2 bg-horror-gray rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-horror-red transition-all duration-1000" 
                      style={{ width: `${Math.min((profile.followerCount / 250) * 100, 100)}%` }}
                    />
                  </div>
                </div>

                {/* Views Progress */}
                <div>
                  <div className="flex justify-between text-xs mb-2">
                    <span className="text-gray-400 uppercase tracking-widest">পাঠ সংখ্যা (১০০০ প্রয়োজন)</span>
                    <span className="text-horror-red font-mono">{profile.totalViews} / 1000</span>
                  </div>
                  <div className="h-2 bg-horror-gray rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-horror-red transition-all duration-1000" 
                      style={{ width: `${Math.min((profile.totalViews / 1000) * 100, 100)}%` }}
                    />
                  </div>
                </div>
              </div>

              {!profile.isMonetized && (
                <div className="mt-12 text-center">
                  <button 
                    disabled={profile.followerCount < 250 || profile.totalViews < 1000}
                    onClick={applyMonetization}
                    className="horror-btn px-12 py-3"
                  >
                    আবেদন করুন
                  </button>
                  <p className="text-[10px] text-gray-500 mt-4 uppercase tracking-[0.3em]">অপেক্ষমাণ ফলাফল অ্যাডমিন দ্বারা যাচাই করা হবে</p>
                </div>
              )}

              {profile.isMonetized && (
                <div className="mt-12 space-y-6">
                  <div className="bg-green-900/10 border border-green-500/20 p-6 rounded-lg">
                    <div className="flex justify-between items-center mb-4">
                      <p className="text-green-500 font-bold">মোট উপার্জন</p>
                      <p className="text-xl font-mono text-white">৳ {profile.earnings || 0}</p>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px] uppercase text-gray-500 font-bold">
                        <span>১০০০ টাকা প্রগ্রেস</span>
                        <span>{Math.min(((profile.earnings || 0) / 1000) * 100, 100).toFixed(1)}%</span>
                      </div>
                      <div className="h-3 bg-horror-black border border-horror-gray rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-green-600 to-green-400 transition-all duration-1000" 
                          style={{ width: `${Math.min(((profile.earnings || 0) / 1000) * 100, 100)}%` }}
                        />
                      </div>
                    </div>
                    
                    {profile.earnings >= 1000 && (
                      <button 
                        onClick={triggerWithdrawal}
                        className="w-full mt-6 py-3 bg-green-600 text-black font-bold rounded hover:bg-green-500 transition-all uppercase tracking-widest text-xs"
                      >
                        উত্তোলনের জন্য অনুরোধ পাঠান
                      </button>
                    )}
                  </div>
                  <p className="text-center text-[10px] text-gray-500 uppercase italic">"প্রতি ১০০০ টাকা পূর্ণ হলে উত্তোলনের অনুরোধ করা যাবে"</p>
                </div>
              )}
            </div>

            <div className="bg-horror-red/5 border border-horror-red/20 p-6 rounded-lg flex gap-4">
              <AlertCircle className="text-horror-red shrink-0" />
              <div className="text-sm text-gray-400">
                <p className="font-bold text-horror-red mb-1">সতর্কবাণী</p>
                <p>যেকোনো ধরণের স্প্যাম বা ফেক অ্যাকাউন্ট ব্যবহারের মাধ্যমে অগ্রগতি লাভ করলে আপনার অ্যাকাউন্ট নিষিদ্ধ করা হতে পারে।</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Edit Profile Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="horror-card w-full max-w-md p-8">
            <h2 className="horror-title text-2xl mb-6">প্রোফাইল আপডেট</h2>
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] uppercase text-gray-500 font-bold">নাম</label>
                <input 
                  type="text" 
                  className="horror-input" 
                  value={editData.displayName}
                  onChange={(e) => setEditData({...editData, displayName: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase text-gray-500 font-bold">প্রোফাইল ছবি ইউআরএল</label>
                <input 
                  type="text" 
                  className="horror-input" 
                  value={editData.photoURL}
                  onChange={(e) => setEditData({...editData, photoURL: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase text-gray-500 font-bold">বায়ো / নিজের সম্পর্কে</label>
                <textarea 
                  className="horror-input min-h-[100px]" 
                  value={editData.bio}
                  onChange={(e) => setEditData({...editData, bio: e.target.value})}
                />
              </div>
              <div className="flex gap-4 pt-4">
                <button type="submit" className="horror-btn flex-1">সেভ করুন</button>
                <button type="button" onClick={() => setIsEditModalOpen(false)} className="px-6 py-2 border border-horror-gray rounded">বাতিল</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* Monetization App Modal */}
      {isAppModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="horror-card w-full max-w-md p-8">
            <h2 className="horror-title text-2xl mb-2 text-yellow-500">মনেটাইজেশন আবেদন</h2>
            <p className="text-xs text-gray-400 mb-6 italic">"অন্ধকার পথে আপনার দক্ষতার স্বীকৃতি"</p>
            <form onSubmit={submitApplication} className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] uppercase text-gray-500 font-bold">পুরো নাম</label>
                <input 
                  type="text" 
                  required
                  className="horror-input" 
                  value={appData.fullName}
                  onChange={(e) => setAppData({...appData, fullName: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase text-gray-500 font-bold">বয়স</label>
                <input 
                  type="number" 
                  required
                  className="horror-input" 
                  value={appData.age}
                  onChange={(e) => setAppData({...appData, age: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase text-gray-500 font-bold">বিকাশ নম্বর</label>
                <input 
                  type="text" 
                  required
                  className="horror-input" 
                  placeholder="01xxxxxxxxx"
                  value={appData.bkash}
                  onChange={(e) => setAppData({...appData, bkash: e.target.value})}
                />
              </div>
              <div className="flex gap-4 pt-4">
                <button type="submit" className="horror-btn bg-yellow-600 hover:bg-yellow-700 text-black flex-1 font-bold">আবেদন জমা দিন</button>
                <button type="button" onClick={() => setIsAppModalOpen(false)} className="px-6 py-2 border border-horror-gray rounded">বাতিল</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default Profile;
