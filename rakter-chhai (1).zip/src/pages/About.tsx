import React from 'react';
import { motion } from 'motion/react';
import { Ghost, ShieldCheck, Mail, Info } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-20">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="horror-card p-12 text-center space-y-8"
      >
        <Ghost className="w-16 h-16 text-horror-red mx-auto animate-bounce" />
        <h1 className="horror-title text-5xl text-horror-red">রক্তের ছাই</h1>
        <p className="text-xl text-gray-400 italic">"কালজয়ী বাংলা ভৌতিক সাহিত্যের ডিজিটাল আর্কাইভ"</p>
        
        <div className="prose prose-invert prose-red mx-auto text-left py-8 border-y border-horror-gray/30">
          <p>
            রক্তের ছাই একটি আধুনিক প্ল্যাটফর্ম যেখানে বাংলা হরর গল্পের লেখক এবং পাঠকরা একত্রিত হন। 
            গথিক ফ্যান্টাসি থেকে শুরু করে লোকজ অতিলৌকিকতা— সব ধরণের গা শিউরে ওঠা গল্পের এক অনন্য ঠিকানা এটি।
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
            <div className="flex gap-4">
              <ShieldCheck className="text-horror-red shrink-0" />
              <div>
                <h3 className="text-white font-bold mb-2">সুরক্ষিত পরিবেশ</h3>
                <p className="text-sm text-gray-500">অ্যাডমিন দ্বারা যাচাইকৃত প্রতিটি গল্প। কোনো স্প্যাম বা অযাচিত বিষবস্তু নয়।</p>
              </div>
            </div>
            <div className="flex gap-4">
              <Info className="text-horror-red shrink-0" />
              <div>
                <h3 className="text-white font-bold mb-2">লেখকদের অধিকার</h3>
                <p className="text-sm text-gray-500">লেখকদের মেধা স্বত্বের পূর্ণ সুরক্ষা এবং নির্দিষ্ট মানদণ্ড অনুযায়ী মনেটাইজেশনের সুযোগ।</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-center gap-6 pt-8">
          <a href="mailto:astbangla2024@gmail.com" className="flex items-center gap-2 hover:text-horror-red transition-all">
            <Mail size={18} /> যোগাযোগ করুন
          </a>
        </div>
      </motion.div>
    </div>
  );
};

export default About;
