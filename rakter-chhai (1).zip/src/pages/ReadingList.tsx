import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, where, getDocs, doc, getDoc, deleteDoc } from 'firebase/firestore';
import { useAuth } from '../hooks/useAuth';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { BookMarked, Trash2, BookOpen, Ghost } from 'lucide-react';
import { toast } from 'sonner';

const ReadingList: React.FC = () => {
  const { user } = useAuth();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const fetchList = async () => {
      try {
        const q = query(collection(db, 'readingLists'), where('userId', '==', user.uid));
        const snap = await getDocs(q);
        
        const storyPromises = snap.docs.map(async (d) => {
          const storyId = d.data().storyId;
          const storyDoc = await getDoc(doc(db, 'stories', storyId));
          return { id: d.id, storyId, ...(storyDoc.data() as any) };
        });

        const results = await Promise.all(storyPromises);
        setItems(results);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchList();
  }, [user]);

  const removeItem = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'readingLists', id));
      setItems(prev => prev.filter(i => i.id !== id));
      toast.success('গল্পটি তালিকা থেকে মুছে ফেলা হয়েছে।');
    } catch (err) {
      toast.error('মুছে ফেলা সম্ভব হয়নি।');
    }
  };

  if (loading) return <div className="text-center py-20">অন্ধকার পথ খুঁজে দেখা হচ্ছে...</div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="flex items-center gap-3 mb-10 pb-4 border-b border-horror-gray">
        <BookMarked className="w-8 h-8 text-horror-red" />
        <h1 className="horror-title text-3xl uppercase tracking-widest">পঠন তালিকা</h1>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {items.map((item) => (
          <motion.div 
            key={item.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="horror-card flex flex-col md:flex-row p-6 gap-6"
          >
            <div className="w-full md:w-48 h-32 shrink-0">
               <img src={item.coverImage || "https://images.unsplash.com/photo-1509248961158-e54f6934749c"} className="w-full h-full object-cover rounded opacity-60" />
            </div>
            
            <div className="flex-1 space-y-2">
              <h3 className="text-xl font-bold font-serif text-horror-red hover:underline">
                <Link to={`/stories/${item.storyId}`}>{item.title}</Link>
              </h3>
              <p className="text-xs text-gray-500 uppercase tracking-widest">{item.authorName} • {item.category}</p>
              <p className="text-sm text-gray-400 line-clamp-2 italic">{item.excerpt}</p>
            </div>

            <div className="flex items-center gap-4">
               <Link to={`/stories/${item.storyId}`} className="p-3 bg-horror-charcoal rounded-full hover:text-horror-red transition-all">
                  <BookOpen size={20} />
               </Link>
               <button onClick={() => removeItem(item.id)} className="p-3 bg-horror-charcoal rounded-full text-gray-600 hover:text-horror-red transition-all">
                  <Trash2 size={20} />
               </button>
            </div>
          </motion.div>
        ))}
        {items.length === 0 && (
          <div className="text-center py-20 opacity-30">
            <Ghost className="w-16 h-16 mx-auto mb-4" />
            <p className="italic">আপনার পঠন তালিকাটি শূন্য।</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReadingList;
