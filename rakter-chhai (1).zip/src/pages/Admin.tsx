import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { useAuth } from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { 
  collection, query, where, getDocs, updateDoc, 
  doc, deleteDoc, orderBy, limit, increment, addDoc
} from 'firebase/firestore';
import { motion } from 'motion/react';
import { 
  Shield, Check, X, Users, BookOpen, 
  Trash2, AlertTriangle, BarChart3, Clock, DollarSign, Ban
} from 'lucide-react';
import { toast } from 'sonner';

const Admin: React.FC = () => {
  const { profile, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'stories' | 'users' | 'monetization' | 'withdrawals'>('stories');
  const [pendingStories, setPendingStories] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [monetizationRequests, setMonetizationRequests] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [stats, setStats] = useState({ users: 0, stories: 0, views: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const isAdmin = profile?.role === 'admin' || profile?.email === 'astbangla2024@gmail.com';
    if (!authLoading && !isAdmin) {
      toast.error('The dark lords restrict access to this chamber.');
      navigate('/');
    }
  }, [profile, authLoading, navigate]);

  useEffect(() => {
    const fetchData = async () => {
      const isAdmin = profile?.role === 'admin' || profile?.email === 'astbangla2024@gmail.com';
      if (!isAdmin) return;
      
      setLoading(true);
      try {
        const storiesRef = collection(db, 'stories');
        
        // Pending Stories
        const pendingQ = query(storiesRef, where('status', '==', 'pending'), orderBy('createdAt', 'desc'));
        const pendingSnap = await getDocs(pendingQ);
        setPendingStories(pendingSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));

        // Users
        const usersSnap = await getDocs(collection(db, 'users'));
        setUsers(usersSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as any)));
        
        // Monetization Requests
        const monetQ = query(collection(db, 'users'), where('monetizationStatus', '==', 'pending'));
        const monetSnap = await getDocs(monetQ);
        setMonetizationRequests(monetSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));

        // Withdrawal Requests (from notifications collection)
        const withQ = query(collection(db, 'notifications'), where('type', '==', 'withdrawal_request'), orderBy('createdAt', 'desc'));
        const withSnap = await getDocs(withQ);
        setWithdrawals(withSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));

        // Stats
        const storyCount = (await getDocs(query(storiesRef, where('status', '==', 'published')))).size;
        const viewCount = usersSnap.docs.reduce((acc, d) => acc + (d.data().totalViews || 0), 0);

        setStats({ users: usersSnap.size, stories: storyCount, views: viewCount });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [profile]);

  const handleApprove = async (id: string, authorId: string) => {
    try {
      await updateDoc(doc(db, 'stories', id), { status: 'published', updatedAt: new Date() });
      setPendingStories(prev => prev.filter(s => s.id !== id));
      toast.success('Story sanctioned for the public.');
      
      // Notify Followers
      const authorName = pendingStories.find(s => s.id === id)?.authorName || 'একজন লেখক';
      const followersSnap = await getDocs(query(collection(db, 'follows'), where('followingId', '==', authorId)));
      
      const notificationPromises = followersSnap.docs.map(f => 
        addDoc(collection(db, 'notifications'), {
          userId: f.data().followerId,
          type: 'publish',
          actorId: authorId,
          actorName: authorName,
          resourceId: id,
          isRead: false,
          createdAt: new Date(),
        })
      );
      await Promise.all(notificationPromises);

      toast.success('Story sanctioned for the public.');
    } catch (err) {
      toast.error('Approval failed.');
    }
  };

  const approveMonetization = async (userId: string) => {
    try {
      await updateDoc(doc(db, 'users', userId), { 
        isMonetized: true,
        monetizationStatus: 'approved',
        earnings: 0
      });

      // Send Approval Notification (Equivalent to the requested email message)
      await addDoc(collection(db, 'notifications'), {
        userId: userId,
        type: 'monetization_approved',
        actorId: 'admin',
        actorName: 'অ্যাডমিন',
        message: 'অভিনন্দন! আপনার মনেটাইজেশন আবেদন অনুমোদিত হয়েছে। এখন থেকে আপনি আপনার গল্প থেকে উপার্জন করতে পারবেন।',
        isRead: false,
        createdAt: new Date(),
      });

      toast.success('Monetization approved. Notification sent to author.');
      setMonetizationRequests(prev => prev.filter(r => r.id !== userId));
    } catch (err) {
      toast.error('Failed to update status.');
    }
  };

  const toggleUserStatus = async (userId: string, isBanned: boolean) => {
    try {
      await updateDoc(doc(db, 'users', userId), { isBanned: !isBanned });
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, isBanned: !isBanned } : u));
      toast.success(isBanned ? 'User unbanned.' : 'User banished.');
    } catch (err) {
      toast.error('Operation failed.');
    }
  };

  const handleReject = async (id: string) => {
    if (window.confirm('Banish this draft forever?')) {
      await deleteDoc(doc(db, 'stories', id));
      setPendingStories(prev => prev.filter(s => s.id !== id));
      toast.info('Chronicle banished.');
    }
  };

  if (loading || authLoading) return <div className="text-center py-20">গোরস্থানের গেট খোলা হচ্ছে...</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex items-center gap-3 mb-12">
        <Shield className="w-10 h-10 text-yellow-500" />
        <h1 className="horror-title text-4xl uppercase tracking-tighter">অ্যাডমিন কন্ট্রোল</h1>
      </div>

      {/* Analytics Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        <StatCard icon={<Users />} label="মোট সদস্য" value={stats.users} color="text-blue-500" />
        <StatCard icon={<BookOpen />} label="প্রকাশিত গল্প" value={stats.stories} color="text-green-500" />
        <StatCard icon={<BarChart3 />} label="মোট পাঠ" value={stats.views} color="text-horror-red" />
      </div>

      {/* Tabs */}
      <div className="flex gap-4 mb-10 border-b border-horror-gray overflow-x-auto pb-1">
        <TabButton active={activeTab === 'stories'} onClick={() => setActiveTab('stories')} label="পাণ্ডুলিপি" count={pendingStories.length} />
        <TabButton active={activeTab === 'users'} onClick={() => setActiveTab('users')} label="সদস্য" />
        <TabButton active={activeTab === 'monetization'} onClick={() => setActiveTab('monetization')} label="মনেটাইজেশন" count={monetizationRequests.length} />
        <TabButton active={activeTab === 'withdrawals'} onClick={() => setActiveTab('withdrawals')} label="উত্তোলন" count={withdrawals.length} />
      </div>

      {/* Content */}
      <div className="min-h-[400px]">
        {activeTab === 'stories' && (
          <div className="space-y-6">
            {pendingStories.map(story => (
              <div key={story.id} className="horror-card p-6 flex flex-col md:flex-row justify-between gap-6">
                <div className="flex-1 space-y-2">
                  <h3 className="text-xl font-bold font-serif text-horror-red underline decoration-horror-red/30 italic">{story.title}</h3>
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span>লেখক: {story.authorName}</span>
                    <span>•</span>
                    <span>বিভাগ: {story.category}</span>
                    {story.scheduledAt && (
                      <>
                        <span>•</span>
                        <span className="flex items-center gap-1 text-yellow-500 font-bold bg-yellow-500/10 px-2 py-0.5 rounded">
                          <Clock size={12} /> {new Date(story.scheduledAt.toDate()).toLocaleString()}
                        </span>
                      </>
                    )}
                  </div>
                  <div className="text-sm text-gray-400 line-clamp-2 italic bg-black/30 p-2 rounded border-l-2 border-horror-red/50">
                    {story.excerpt}...
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <button onClick={() => handleApprove(story.id, story.authorId)} className="p-3 bg-green-900/20 border border-green-500/50 rounded-full text-green-500 hover:bg-green-500 hover:text-black transition-all">
                    <Check />
                  </button>
                  <button onClick={() => handleReject(story.id)} className="p-3 bg-red-900/20 border border-horror-red/50 rounded-full text-horror-red hover:bg-horror-red hover:text-white transition-all">
                    <X />
                  </button>
                  <button onClick={() => navigate(`/stories/${story.id}`)} className="p-3 border border-horror-gray rounded-full text-gray-500 hover:text-white transition-all">
                    <BarChart3 size={24} />
                  </button>
                </div>
              </div>
            ))}
            {pendingStories.length === 0 && <p className="text-center text-gray-500 py-10 italic">কোনো নতুন পাণ্ডুলিপি নেই।</p>}
          </div>
        )}

        {activeTab === 'users' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {users.map(u => (
              <div key={u.id} className="horror-card p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img src={u.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${u.id}`} className="w-10 h-10 rounded-full" />
                  <div>
                    <p className="font-bold text-sm">{u.displayName}</p>
                    <p className="text-[10px] text-gray-500 uppercase">{u.role || 'user'}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => toggleUserStatus(u.id, u.isBanned)} 
                    className={`p-2 rounded-full transition-all ${u.isBanned ? 'bg-red-500 text-black' : 'text-gray-500 hover:text-red-500 hover:bg-red-500/10'}`}
                  >
                    <Ban size={18} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'monetization' && (
          <div className="space-y-4">
            {monetizationRequests.map(req => (
              <div key={req.id} className="horror-card p-6 flex flex-col md:flex-row justify-between items-start gap-6">
                <div className="space-y-4 flex-1">
                  <div className="flex items-center gap-4">
                    <img src={req.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${req.id}`} className="w-12 h-12 rounded-full border border-horror-gray" />
                    <div>
                      <h3 className="text-xl font-bold text-white">{req.displayName}</h3>
                      <p className="text-xs text-gray-500 italic">{req.email}</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-black/40 p-4 rounded border border-horror-red/20">
                    <div>
                      <p className="text-[10px] uppercase text-gray-500 font-bold">আবেদনকারীর নাম</p>
                      <p className="text-sm">{req.monetizationDetails?.fullName || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase text-gray-500 font-bold">বয়স</p>
                      <p className="text-sm">{req.monetizationDetails?.age || 'N/A'} বছর</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase text-gray-500 font-bold">বিকাশ নম্বর</p>
                      <p className="text-sm font-mono text-horror-red">{req.monetizationDetails?.bkash || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase text-gray-500 font-bold">ফলোয়ার / ভিউ</p>
                      <p className="text-sm">{req.followerCount} / {req.totalViews}</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-3 shrink-0">
                  <button onClick={() => approveMonetization(req.id)} className="horror-btn py-2 px-6 bg-green-600 hover:bg-green-700 text-black font-bold">
                    অনুমোদন
                  </button>
                  <button onClick={async () => {
                    await updateDoc(doc(db, 'users', req.id), { monetizationStatus: 'rejected' });
                    setMonetizationRequests(prev => prev.filter(r => r.id !== req.id));
                    toast.info('Application rejected.');
                  }} className="px-6 py-2 border border-horror-gray rounded hover:bg-red-900/20">বাতিল</button>
                </div>
              </div>
            ))}
            {monetizationRequests.length === 0 && <p className="text-center text-gray-500 py-10 italic">কোনো নতুন মনেটাইজেশন রিকোয়েস্ট নেই।</p>}
          </div>
        )}

        {activeTab === 'withdrawals' && (
          <div className="space-y-4">
            {withdrawals.map(req => (
              <div key={req.id} className="horror-card p-6 border-yellow-500/20">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <DollarSign className="text-yellow-500" />
                    <div>
                      <p className="font-bold text-white uppercase tracking-tighter">উত্তোলন অনুরোধ</p>
                      <p className="text-[10px] text-gray-500">{new Date(req.createdAt?.toDate()).toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-mono text-yellow-500">৳ ১০০০</p>
                    <p className="text-[10px] text-gray-500">বিকাশ পেমেন্ট</p>
                  </div>
                </div>
                
                <div className="bg-black/50 p-4 rounded border border-horror-gray mb-6">
                  <div className="flex items-center gap-4 mb-3">
                    <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${req.actorId}`} className="w-10 h-10 rounded-full" />
                    <div>
                      <p className="font-bold">{req.actorName}</p>
                      <p className="text-xs text-gray-500">ID: {req.actorId}</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-300 italic">"{req.message || 'উত্তোলনের জন্য অনুরোধ করা হয়েছে।'}"</p>
                </div>

                <div className="flex gap-4">
                  <button 
                    onClick={async () => {
                      // Process withdrawal
                      await updateDoc(doc(db, 'users', req.actorId), { earnings: increment(-1000) });
                      await deleteDoc(doc(db, 'notifications', req.id));
                      setWithdrawals(prev => prev.filter(w => w.id !== req.id));
                      toast.success('Withdrawal processed!');
                    }}
                    className="flex-1 py-3 bg-yellow-600 text-black font-bold rounded hover:bg-yellow-700 transition-all uppercase tracking-widest text-xs"
                  >
                    পেমেন্ট সম্পন্ন হয়েছে
                  </button>
                  <button 
                    onClick={async () => {
                      await deleteDoc(doc(db, 'notifications', req.id));
                      setWithdrawals(prev => prev.filter(w => w.id !== req.id));
                      toast.info('Request dismissed.');
                    }}
                    className="px-6 py-3 border border-horror-gray rounded hover:bg-red-900/20 text-xs uppercase"
                  >
                    বাতিল
                  </button>
                </div>
              </div>
            ))}
            {withdrawals.length === 0 && <p className="text-center text-gray-500 py-10 italic">কোনো উত্তোলনের অনুরোধ নেই।</p>}
          </div>
        )}
      </div>
    </div>
  );
};

const TabButton = ({ active, onClick, label, count }: any) => (
  <button 
    onClick={onClick}
    className={`pb-3 px-4 text-xs uppercase tracking-widest transition-all relative ${active ? 'text-horror-red font-bold' : 'text-gray-500'}`}
  >
    {label}
    {count !== undefined && count > 0 && <span className="ml-2 bg-horror-red text-white text-[9px] px-1 rounded-full">{count}</span>}
    {active && <motion.div layoutId="admintab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-horror-red" />}
  </button>
);

const StatCard = ({ icon, label, value, color }: any) => (
  <div className="horror-card p-6 border-horror-gray/30 bg-black/40">
    <div className="flex items-center gap-4">
      <div className={`p-4 bg-gray-900 rounded-lg ${color}`}>{icon}</div>
      <div>
        <p className="text-[10px] uppercase tracking-widest text-gray-500 mb-1">{label}</p>
        <p className="text-3xl font-black font-mono">{value.toLocaleString()}</p>
      </div>
    </div>
  </div>
);


export default Admin;
