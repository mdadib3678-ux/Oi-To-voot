import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { db } from '../lib/firebase';
import { doc, getDoc, setDoc, updateDoc, serverTimestamp, collection, Timestamp } from 'firebase/firestore';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';
import { Save, Send, Sparkles, Image, Eye, EyeOff, Layout, Type, Terminal, Shield, Clock } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { suggestStoryImprovements, getPlotIdeas } from '../lib/ai';

const Editor: React.FC = () => {
  const [searchParams] = useSearchParams();
  const id = searchParams.get('id');
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [category, setCategory] = useState('Supernatural');
  const [tags, setTags] = useState('');
  const [isPreview, setIsPreview] = useState(false);
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<string | null>(null);
  const [plagiarismResult, setPlagiarismResult] = useState<{ score: number, message: string } | null>(null);
  const [scheduledAt, setScheduledAt] = useState<string>('');
  const [isScheduled, setIsScheduled] = useState(false);

  const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;
  
  const [guestName, setGuestName] = useState('অজ্ঞাত লেখক');

  const checkPlagiarism = async () => {
    if (!content || content.length < 100) {
      toast.error("পর্যাপ্ত লেখা না থাকলে পরীক্ষা করা সম্ভব নয়।");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/plagiarism-check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
      });
      const data = await res.json();
      setPlagiarismResult(data);
      if (data.isPlagiarized) {
        toast.error(data.message, { duration: 5000 });
      } else {
        toast.success(data.message);
      }
    } catch (err) {
      toast.error("প্লেজিয়ারিজম সেবাটি বর্তমানে কাজ করছে না।");
    } finally {
      setLoading(false);
    }
  };
  const categories = ['Supernatural', 'Psychological', 'Urban legend', 'Folk horror'];

  useEffect(() => {
    if (id) {
      const fetchStory = async () => {
        const docRef = doc(db, 'stories', id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          // Only allow editing if the user is the author or admin, OR it's a guest story and we don't have user info (less secure but requested)
          if (user && data.authorId !== user.uid && profile?.role !== 'admin') {
            toast.error('This dark chronicle is not yours.');
            navigate('/');
            return;
          }
          setTitle(data.title);
          setContent(data.content);
          setCoverImage(data.coverImage);
          setCategory(data.category);
          setTags(data.tags?.join(', ') || '');
          if (data.scheduledAt) {
            const date = data.scheduledAt.toDate();
            // Format to YYYY-MM-DDTHH:mm
            const formatted = date.toISOString().slice(0, 16);
            setScheduledAt(formatted);
            setIsScheduled(true);
          }
        }
      }
      fetchStory();
    }
  }, [id, user, profile, navigate]);

  const handleSave = async (isPublish: boolean = false) => {
    if (wordCount < 200) {
      toast.error(`At least 200 words are required to summon a true horror. Current: ${wordCount}`);
      return;
    }

    setLoading(true);
    try {
      const storyId = id || doc(collection(db, 'stories')).id;
      const storyData = {
        title,
        content,
        excerpt: content.substring(0, 150) + '...',
        coverImage,
        category,
        tags: tags.split(',').map(t => t.trim()),
        authorId: user?.uid || 'guest',
        authorName: profile?.displayName || user?.displayName || guestName || 'অজানা আত্মা',
        authorPhoto: profile?.photoURL || user?.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${guestName}`,
        wordCount,
        status: isPublish ? 'pending' : 'draft', // Admin review required
        scheduledAt: (isPublish && isScheduled && scheduledAt) ? Timestamp.fromDate(new Date(scheduledAt)) : null,
        updatedAt: serverTimestamp(),
      };

      if (!id) {
        (storyData as any).createdAt = serverTimestamp();
        (storyData as any).viewCount = 0;
        (storyData as any).likeCount = 0;
      }

      await setDoc(doc(db, 'stories', storyId), storyData, { merge: true });
      toast.success(isPublish ? 'Story submitted for ritual (admin review)!' : 'Draft preserved in the shadows.');
      
      if (isPublish) {
        if (user) navigate(`/profile/${user.uid}`);
        else navigate('/');
      }
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAiAssist = async () => {
    if (!content) {
      toast.error('Write something first, so the spirits can assist.');
      return;
    }
    setAiLoading(true);
    const suggestions = await suggestStoryImprovements(title, content);
    setAiSuggestions(suggestions);
    setAiLoading(false);
  };

  const handlePlotHelp = async () => {
    setAiLoading(true);
    const ideas = await getPlotIdeas(category);
    setAiSuggestions(ideas);
    setAiLoading(false);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Tab Controls */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsPreview(false)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full border border-horror-gray transition-all ${!isPreview ? 'bg-horror-red border-horror-red text-white' : 'hover:border-horror-red/50 hover:text-horror-red'}`}
          >
            <Type size={18} /> <span>এডিটর</span>
          </button>
          <button 
            onClick={() => setIsPreview(true)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full border border-horror-gray transition-all ${isPreview ? 'bg-horror-red border-horror-red text-white' : 'hover:border-horror-red/50 hover:text-horror-red'}`}
          >
            <Eye size={18} /> <span>প্রিভিউ</span>
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={handleAiAssist} 
            disabled={aiLoading}
            className="flex items-center gap-2 px-4 py-2 bg-purple-900/30 border border-purple-500/50 rounded-full text-purple-200 hover:bg-purple-900/50 transition-all disabled:opacity-50"
          >
            <Sparkles size={18} className={aiLoading ? 'animate-spin' : ''} />
            <span className="hidden md:inline">AI এডিট</span>
          </button>
          <button 
            onClick={checkPlagiarism}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 border border-horror-gray rounded-full hover:border-horror-red transition-all text-xs"
          >
            <Shield size={18} />
            <span className="hidden md:inline">কপিরাইট চেক</span>
          </button>
          <button 
            onClick={() => handleSave(false)} 
            disabled={loading}
            className="p-2 border border-horror-gray rounded-full hover:border-horror-red transition-all"
          >
            <Save size={18} />
          </button>
          <button 
            onClick={() => handleSave(true)} 
            disabled={loading}
            className="flex items-center gap-2 horror-btn"
          >
            <Send size={18} />
            <span>বার্তা পাঠান</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          {isPreview ? (
            <div className="horror-card p-10 min-h-[60vh] prose prose-invert prose-red max-w-none">
              <h1 className="horror-title text-4xl mb-8">{title || 'গল্পের শিরোনাম নেই'}</h1>
              {coverImage && <img src={coverImage} className="w-full h-80 object-cover rounded-lg mb-8" alt="Cover" />}
              <div className="text-gray-300">
                <ReactMarkdown>{content || 'অন্ধকারের প্রতীক্ষায়...'}</ReactMarkdown>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              {!user && !id && (
                <div className="horror-card p-4 border-horror-red/30 mb-8">
                  <label className="text-[10px] uppercase text-gray-500 block mb-2 font-bold tracking-widest">আপনার ছদ্মনাম (Guest Name)</label>
                  <input 
                    type="text" 
                    placeholder="অজ্ঞাত লেখক" 
                    className="bg-transparent border-b border-horror-gray w-full py-2 outline-none text-horror-red font-serif italic"
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                  />
                </div>
              )}
              <textarea
                placeholder="গল্পের শিরোনাম..."
                className="w-full bg-transparent horror-title text-4xl md:text-5xl outline-none resize-none placeholder:text-gray-800"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                rows={1}
              />

              <div className="flex items-center gap-4 py-4 border-y border-horror-gray/50 overflow-x-auto no-scrollbar">
                <span className="text-xs uppercase tracking-widest text-horror-red">বিভাগ:</span>
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setCategory(cat)}
                    className={`px-3 py-1 text-xs rounded border border-horror-gray transition-all ${category === cat ? 'bg-horror-red/20 border-horror-red text-horror-red' : 'hover:border-horror-red/30'}`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              <textarea
                placeholder="গল্পের মূল কথা এখানে শুরু করুন..."
                className="w-full bg-transparent min-h-[60vh] outline-none resize-none text-lg leading-relaxed placeholder:text-gray-800"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="horror-card p-4 space-y-4">
            <h3 className="text-xs uppercase tracking-widest text-gray-500 font-bold mb-4">গল্পের তথ্যাবলী</h3>
            
            <div className="space-y-2">
              <label className="text-[10px] uppercase text-horror-red">Cover Image URL</label>
              <div className="relative">
                <Image className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
                <input 
                  type="text" 
                  className="horror-input text-xs pl-8 py-2" 
                  placeholder="https://..." 
                  value={coverImage}
                  onChange={(e) => setCoverImage(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase text-horror-red">Tags (comma separated)</label>
              <input 
                type="text" 
                className="horror-input text-xs" 
                placeholder="ভয়, আত্মা, অন্ধকার..." 
                value={tags}
                onChange={(e) => setTags(e.target.value)}
              />
            </div>

            <div className="pt-4 border-t border-horror-gray flex justify-between items-center">
              <span className="text-[10px] uppercase text-gray-500">শব্দ সংখ্যা:</span>
              <span className={`text-sm font-mono ${wordCount < 200 ? 'text-horror-red' : 'text-green-500'}`}>
                {wordCount} / 200
              </span>
            </div>
          </div>

          <div className="horror-card p-4 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs uppercase tracking-widest text-gray-500 font-bold">শিডিউল পাবলিশ</h3>
              <input 
                type="checkbox" 
                checked={isScheduled} 
                onChange={(e) => setIsScheduled(e.target.checked)}
                className="accent-horror-red"
              />
            </div>
            {isScheduled && (
              <div className="space-y-2">
                <label className="text-[10px] uppercase text-horror-red">পাবলিশের সময়</label>
                <div className="relative">
                  <Clock className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-600" />
                  <input 
                    type="datetime-local" 
                    className="horror-input text-[10px] pl-8 py-2" 
                    value={scheduledAt}
                    onChange={(e) => setScheduledAt(e.target.value)}
                  />
                </div>
                <p className="text-[8px] text-gray-500 italic">"নির্দিষ্ট সময়ে গল্পটি পেন্ডিং থেকে পাবলিশড হবে (ম্যানুয়াল ভেরিফিকেশন প্রযোজ্য)"</p>
              </div>
            )}
          </div>

          <div className="horror-card p-4">
            <button onClick={handlePlotHelp} className="w-full flex items-center justify-between text-xs hover:text-horror-red transition-all">
              <span className="uppercase tracking-widest">প্লট আইডিয়া দরকার?</span>
              <Sparkles size={14} />
            </button>
          </div>

          <AnimatePresence>
            {aiSuggestions && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="horror-card p-4 border-purple-500/30 bg-purple-900/5 relative"
              >
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-[10px] uppercase text-purple-400 font-bold flex items-center gap-1">
                    <Terminal size={12} /> AI আত্মার পরামর্শ
                  </h4>
                  <button onClick={() => setAiSuggestions(null)} className="text-gray-500 hover:text-white"><EyeOff size={14} /></button>
                </div>
                <div className="text-xs text-purple-100/80 prose prose-invert prose-sm leading-relaxed max-height-[300px] overflow-y-auto no-scrollbar">
                  <ReactMarkdown>{aiSuggestions}</ReactMarkdown>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default Editor;
