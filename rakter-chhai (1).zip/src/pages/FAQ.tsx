import React from 'react';
import { motion } from 'motion/react';
import { HelpCircle, ChevronDown } from 'lucide-react';

const FAQ: React.FC = () => {
  const faqs = [
    {
      q: "গল্প কিভাবে পোস্ট করব?",
      a: "প্রথমে একটি অ্যাকাউন্ট তৈরি করুন। তারপর 'লিখুন' বাটনে ক্লিক করে আপনার গল্প ডাফট বা পাবলিশের জন্য পাঠাতে পারেন।"
    },
    {
      q: "মনোটাউজেশন বা আয় করার প্রক্রিয়া কী?",
      a: "যখন আপনার ২৫০ জন ফলোয়ার এবং ১০০০টির বেশি ভিউ হবে, তখন আপনি প্রফাইল থেকে মনেটাইজেশনের জন্য আবেদন করতে পারবেন।"
    },
    {
      q: "গল্প কি সাথে সাথে প্রকাশিত হয়?",
      a: "না, প্রতিটি গল্প আমাদের অ্যাডমিন টিম দ্বারা যাচাই করার পর ২৪-৪৮ ঘণ্টার মধ্যে প্রকাশিত হয়।"
    },
    {
      q: "আমি কি অন্য কারো গল্প কপি করে দিতে পারি?",
      a: "একেবারেই না। আমাদের সিসেটমে প্লেজিয়ারিজম ডিটেক্টর আছে। কপি করা গল্প ধরা পড়লে অ্যাকাউন্ট আজীবনের জন্য ব্যান করা হবে।"
    }
  ];

  return (
    <div className="max-w-3xl mx-auto px-4 py-20">
      <div className="text-center mb-16 space-y-4">
        <HelpCircle className="w-12 h-12 text-horror-red mx-auto" />
        <h1 className="horror-title text-4xl uppercase tracking-widest">সাধারণ জিজ্ঞাসা</h1>
        <p className="text-gray-500 italic">"অন্ধকার পথে আপনার সব প্রশ্নের উত্তর এখানে..."</p>
      </div>

      <div className="space-y-4">
        {faqs.map((faq, i) => (
          <details key={i} className="horror-card group">
            <summary className="flex items-center justify-between p-6 cursor-pointer list-none">
              <span className="font-bold text-gray-200">{faq.q}</span>
              <ChevronDown className="text-horror-red transition-transform group-open:rotate-180" />
            </summary>
            <div className="px-6 pb-6 text-gray-400 border-t border-horror-gray pt-4 text-sm leading-relaxed">
              {faq.a}
            </div>
          </details>
        ))}
      </div>
    </div>
  );
};

export default FAQ;
