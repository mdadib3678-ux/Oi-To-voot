import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, where, orderBy, limit, getDocs } from 'firebase/firestore';
import { Link, useSearchParams } from 'react-router-dom';
import { motion } from 'motion/react';
import { TrendingUp, Clock, Ghost, ChevronRight, Sparkles, Filter, Eye, Heart, MessageSquare, Trophy, Mail } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const Home: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const urlCategory = searchParams.get('cat');

  const [trending, setTrending] = useState<any[]>([]);
  const [latest, setLatest] = useState<any[]>([]);
  const [topAuthors, setTopAuthors] = useState<any[]>([]);
  const [categoryStories, setCategoryStories] = useState<any[]>([]);
  const [selectedCategory, setSelectedCategory] = useState(urlCategory || 'Supernatural');
  const [loading, setLoading] = useState(true);

  const categories = ['Supernatural', 'Psychological', 'Urban legend', 'Folk horror'];

  useEffect(() => {
    if (urlCategory && categories.includes(urlCategory)) {
      setSelectedCategory(urlCategory);
    }
  }, [urlCategory]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const storiesRef = collection(db, 'stories');
        
        // Trending
        const trendingQ = query(storiesRef, where('status', '==', 'published'), orderBy('viewCount', 'desc'), limit(3));
        const trendingSnap = await getDocs(trendingQ);
        setTrending(trendingSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));

        // Latest
        const latestQ = query(storiesRef, where('status', '==', 'published'), orderBy('createdAt', 'desc'), limit(6));
        const latestSnap = await getDocs(latestQ);
        setLatest(latestSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));

        // Top Authors
        const usersRef = collection(db, 'users');
        const usersQ = query(usersRef, orderBy('totalViews', 'desc'), limit(5));
        const usersSnap = await getDocs(usersQ);
        setTopAuthors(usersSnap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const fetchCategory = async () => {
      const storiesRef = collection(db, 'stories');
      const categoryQ = query(storiesRef, where('status', '==', 'published'), where('category', '==', selectedCategory), limit(4));
      const snap = await getDocs(categoryQ);
      setCategoryStories(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    };
    fetchCategory();
  }, [selectedCategory]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      {/* Hero Section */}
      <section className="mb-20 text-center">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="horror-title text-5xl md:text-7xl text-horror-red mb-4"
        >
          রক্তের ছাই
        </motion.h1>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto italic font-serif">
          "অন্ধকারে জেগে থাকা প্রতিটি শব্দই এক একটি গল্প..."
        </p>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-16">
          
          {/* Latest Stories */}
          <section>
            <div className="flex items-center gap-2 mb-8">
              <Clock className="text-horror-red w-6 h-6" />
              <h2 className="horror-title text-2xl uppercase border-b border-horror-red/30 pb-1">সদ্য প্রকাশিত</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {latest.map(story => (
                <StoryCard key={story.id} story={story} />
              ))}
            </div>
          </section>

          {/* Category-based browsing */}
          <section>
            <div className="flex items-center justify-between mb-8 overflow-x-auto gap-4 py-2 no-scrollbar">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-1 rounded-full border border-horror-gray transition-all whitespace-nowrap ${selectedCategory === cat ? 'bg-horror-red border-horror-red text-white' : 'hover:border-horror-red/50 hover:text-horror-red'}`}
                >
                  {cat}
                </button>
              ))}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {categoryStories.map(story => (
                <StoryCard key={story.id} story={story} />
              ))}
              {categoryStories.length === 0 && <p className="text-gray-500 italic">এই বিভাগে কোনো গল্প নেই...</p>}
            </div>
          </section>
        </div>

        {/* Sidebar */}
        <aside className="space-y-12">
          {/* Trending */}
          <section>
            <div className="flex items-center gap-2 mb-6">
              <TrendingUp className="text-horror-red w-6 h-6" />
              <h2 className="horror-title text-xl uppercase">ট্রেন্ডিং</h2>
            </div>
            <div className="space-y-6">
              {trending.map((story, i) => (
                <div key={story.id} className="flex gap-4 group">
                  <span className="text-4xl font-serif font-black text-horror-gray group-hover:text-horror-red transition-colors">0{i + 1}</span>
                  <div>
                    <h3 className="font-bold leading-tight group-hover:text-horror-red transition-colors">
                      <Link to={`/stories/${story.id}`}>{story.title}</Link>
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">{story.authorName}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Top Authors */}
          <section className="horror-card p-6 border-horror-red/30">
            <h2 className="horror-title text-lg uppercase flex items-center gap-2 text-horror-red mb-6">
              <Trophy size={18} /> শ্রেষ্ঠ গল্পকার
            </h2>
            <div className="space-y-6">
              {topAuthors.map((author, index) => (
                <Link key={author.id} to={`/profile/${author.id}`} className="flex items-center gap-4 group">
                  <div className="relative">
                    <img 
                      src={author.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${author.id}`} 
                      className="w-10 h-10 rounded-full border border-horror-gray group-hover:border-horror-red transition-all"
                      alt={author.displayName}
                    />
                    <span className="absolute -top-1 -left-1 w-4 h-4 bg-horror-charcoal border border-horror-red rounded-full flex items-center justify-center text-[8px] font-bold text-horror-red">
                      {index + 1}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-sm font-bold group-hover:text-horror-red transition-colors">{author.displayName}</h3>
                    <p className="text-[10px] text-gray-500 uppercase tracking-tighter">
                      {author.totalViews || 0} ভিউস • {author.followerCount || 0} ফলোয়ার
                    </p>
                  </div>
                </Link>
              ))}
              {topAuthors.length === 0 && <p className="text-[10px] text-gray-500 italic">এখনো কোনো তথ্য নেই...</p>}
            </div>
          </section>

          {/* AI Recommendations (Simulated) */}
          <section className="bg-horror-red/5 border border-horror-red/20 rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="text-horror-red w-5 h-5 animate-pulse" />
              <h2 className="horror-title text-lg uppercase text-horror-red">AI বাছাই</h2>
            </div>
            <p className="text-xs text-gray-400 mb-4 italic">আপনার রুচি অনুযায়ী আত্মা দ্বারা নির্বাচিত...</p>
            {/* Simulation logic would go here */}
            <div className="space-y-3">
              <Link to="#" className="block text-sm hover:text-horror-red transition-colors">• মধ্যরাতের সেই নূপুরধ্বনি</Link>
              <Link to="#" className="block text-sm hover:text-horror-red transition-colors">• পুরোনো আয়নার অভিশাপ</Link>
              <Link to="#" className="block text-sm hover:text-horror-red transition-colors">• স্টেশনের শেষ গাড়িটি</Link>
            </div>
          </section>

          {/* Newsletter Box */}
          <section className="bg-black/60 border border-horror-red/30 p-6 rounded-lg text-center">
             <Mail className="mx-auto text-horror-red mb-4" size={32} />
             <h3 className="horror-title text-lg mb-2">অন্ধকারের চিঠিপত্র</h3>
             <p className="text-[10px] text-gray-500 mb-6 uppercase tracking-widest">নতুন গল্পের আপডেট পেতে সাবস্ক্রাইব করুন</p>
             <div className="flex gap-2">
               <input type="email" placeholder="ইমেইল ঠিকানা" className="horror-input text-[10px] py-1" />
               <button className="horror-btn py-1 px-4 text-[10px]">সাবস্ক্রাইব</button>
             </div>
          </section>
        </aside>
      </div>
    </div>
  );
};

const StoryCard = ({ story }: { story: any }) => (
  <motion.div 
    whileHover={{ y: -5 }}
    className="horror-card group flex flex-col h-full overflow-hidden"
  >
    <div className="relative overflow-hidden">
      {story.coverImage && (
        <div className="h-48 overflow-hidden">
          <Link to={`/stories/${story.id}`}>
            <img 
              src={story.coverImage} 
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-80 group-hover:opacity-100"
              alt={story.title}
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-horror-black/80 to-transparent opacity-60" />
          </Link>
        </div>
      )}
      <div className="absolute top-2 right-2 px-2 py-1 bg-black/80 text-[10px] uppercase tracking-widest text-horror-red border border-horror-red/50 backdrop-blur-sm font-bold">
        {story.category}
      </div>
    </div>
    <div className="p-4 flex-1 flex flex-col">
      <div className="flex items-center gap-2 mb-2">
        <img 
          src={story.authorPhoto || `https://api.dicebear.com/7.x/avataaars/svg?seed=${story.authorId}`} 
          className="w-5 h-5 rounded-full border border-horror-gray"
          alt={story.authorName}
          referrerPolicy="no-referrer"
        />
        <Link to={`/profile/${story.authorId}`} className="text-[10px] text-gray-400 hover:text-horror-red uppercase tracking-wider transition-colors">{story.authorName}</Link>
      </div>
      <Link to={`/stories/${story.id}`}>
        <h3 className="text-lg font-bold mb-2 group-hover:text-horror-red transition-colors line-clamp-2 leading-snug">{story.title}</h3>
      </Link>
      <p className="text-xs text-gray-500 line-clamp-3 mb-4 font-serif italic">{story.excerpt}</p>
      
      <div className="mt-auto pt-4 border-t border-horror-gray/30">
        <div className="flex items-center justify-between mb-3">
          <div className="flex gap-4">
            <span className="flex items-center gap-1 text-[10px] text-gray-500" title="ভিউ">
              <Eye size={12} className="text-horror-red/70" /> {story.viewCount || 0}
            </span>
            <span className="flex items-center gap-1 text-[10px] text-gray-500" title="লাইক">
              <Heart size={12} className="text-horror-red/70" /> {story.likeCount || 0}
            </span>
            <span className="flex items-center gap-1 text-[10px] text-gray-500" title="কমেন্ট">
              <MessageSquare size={12} className="text-horror-red/70" /> {story.commentCount || 0}
            </span>
          </div>
          <span className="text-[10px] text-gray-600 italic">
            {story.createdAt ? formatDistanceToNow(story.createdAt.toDate()) : 'সময়ের অতীত'} আগে
          </span>
        </div>
        <Link to={`/stories/${story.id}`} className="text-horror-red hover:underline text-xs flex items-center justify-center gap-1 bg-horror-gray/10 py-1.5 rounded border border-horror-gray/30 hover:bg-horror-red/10 transition-all font-bold tracking-widest uppercase">
          অন্ধকারে ডুব দিন <ChevronRight size={14} />
        </Link>
      </div>
    </div>
  </motion.div>
);

export default Home;
