import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db } from '../lib/firebase';
import { 
  GoogleAuthProvider,
  signInWithPopup
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { toast } from 'sonner';
import { motion } from 'motion/react';
import { Ghost, LogIn } from 'lucide-react';

interface AuthProps {
  mode: 'login' | 'signup';
}

const Auth: React.FC<AuthProps> = ({ mode }) => {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Simple "Ghost Captcha"
  const [captchaCode, setCaptchaCode] = useState(() => Math.random().toString(36).substring(2, 7).toUpperCase());
  const [captchaInput, setCaptchaInput] = useState('');

  const refreshCaptcha = () => {
    setCaptchaCode(Math.random().toString(36).substring(2, 7).toUpperCase());
    setCaptchaInput('');
  };

  const handleGoogleSignIn = async () => {
    if (captchaInput.toUpperCase() !== captchaCode) {
      toast.error('ভুল ক্যাপচা! আত্মারা আপনাকে চিনতে পারছে না।');
      refreshCaptcha();
      return;
    }

    setLoading(true);
    const provider = new GoogleAuthProvider();
    
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      // Check if user profile exists
      const userDocRef = doc(db, 'users', user.uid);
      const userDoc = await getDoc(userDocRef);

      const isAdminEmail = user.email === 'astbangla2024@gmail.com';

      if (!userDoc.exists()) {
        // Create new profile for first-time login
        await setDoc(userDocRef, {
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL,
          role: isAdminEmail ? 'admin' : 'user',
          isMonetized: false,
          followerCount: 0,
          followingCount: 0,
          totalViews: 0,
          createdAt: serverTimestamp(),
          isBanned: false,
          monetizationStatus: 'none'
        });
        toast.success(isAdminEmail ? 'এডমিন হিসেবে স্বাগতম!' : 'রক্তের ছাই-এ আপনাকে স্বাগতম!');
      } else {
        if (userDoc.data()?.isBanned) {
          toast.error('আপনার আত্মা এই প্ল্যাটফর্ম থেকে বিতাড়িত (ব্যান) করা হয়েছে।');
          await auth.signOut();
          setLoading(false);
          return;
        }

        // If it's the admin email but role is not admin, upgrade it
        if (isAdminEmail && userDoc.data()?.role !== 'admin') {
          await setDoc(userDocRef, { role: 'admin' }, { merge: true });
        }

        toast.success(isAdminEmail ? 'ছায়ায় ফিরে আসার জন্য ধন্যবাদ, অ্যাডমিন।' : 'ছায়ায় ফিরে আসার জন্য ধন্যবাদ।');
      }

      navigate('/');
    } catch (error: any) {
      console.error(error);
      toast.error('লগইন ব্যর্থ হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-20 p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="horror-card p-8"
      >
        <div className="flex justify-center mb-6">
          <Ghost className="w-12 h-12 text-horror-red" />
        </div>
        
        <h2 className="horror-title text-3xl text-center mb-4">
          {mode === 'signup' ? 'রক্তের ছাই-এ যোগ দিন' : 'ছায়ায় প্রবেশ করুন'}
        </h2>
        
        <p className="text-gray-500 text-center text-sm mb-8 italic">
          "অন্ধকারে যাত্রা শুরু করতে নিজের পরিচয় নিশ্চিত করুন"
        </p>

        <div className="space-y-6">
          {/* Spooky Captcha */}
          <div className="bg-black/50 p-4 border border-horror-gray rounded">
            <label className="text-[10px] text-gray-500 mb-2 block uppercase tracking-widest font-bold">Ghost Captcha</label>
            <div className="flex items-center gap-4">
              <div 
                className="flex-1 bg-horror-red/10 text-horror-red font-mono text-xl tracking-[0.4em] px-4 py-2 border border-horror-red/20 italic select-none line-through decoration-horror-red/50 text-center"
                style={{ textShadow: '0 0 8px rgba(139,0,0,0.5)' }}
              >
                {captchaCode}
              </div>
            </div>
            <input
              type="text"
              placeholder="ওপরের কোডটি এখানে লিখুন"
              className="horror-input mt-3 text-center uppercase tracking-widest"
              value={captchaInput}
              onChange={(e) => setCaptchaInput(e.target.value)}
              required
            />
            <button 
              type="button" 
              onClick={refreshCaptcha}
              className="text-[10px] text-horror-red mt-2 hover:underline w-full text-center"
            >
              কোড পরিবর্তন করুন
            </button>
          </div>

          <button
            onClick={handleGoogleSignIn}
            disabled={loading || !captchaInput}
            className="w-full h-14 flex items-center justify-center gap-3 bg-white text-black font-bold rounded hover:bg-gray-200 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <div className="w-6 h-6 border-2 border-horror-red border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/pwa_list/google.svg" className="w-6 h-6" alt="Google" />
                <span>গুগল দিয়ে {mode === 'signup' ? 'সাইনআপ' : 'লগইন'} করুন</span>
              </>
            )}
          </button>
        </div>

        <p className="mt-8 text-center text-[10px] text-gray-600 uppercase tracking-widest leading-relaxed">
          প্রবেশ করার মাধ্যমে আপনি আমাদের অন্ধকারের নিয়মাবলী ও শর্তসমূহ মেনে নিচ্ছেন।
        </p>
      </motion.div>
    </div>
  );
};

export default Auth;
