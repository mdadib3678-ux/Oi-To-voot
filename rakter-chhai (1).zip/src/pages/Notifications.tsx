import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, where, orderBy, onSnapshot, updateDoc, doc } from 'firebase/firestore';
import { useAuth } from '../hooks/useAuth';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, Heart, MessageSquare, UserPlus, Award, Ghost } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Link } from 'react-router-dom';

const Notifications: React.FC = () => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'notifications'), 
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snap) => {
      setNotifications(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const markAllRead = async () => {
    notifications.forEach(async (n) => {
      if (!n.isRead) {
        await updateDoc(doc(db, 'notifications', n.id), { isRead: true });
      }
    });
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'comment': return <MessageSquare className="text-blue-500" />;
      case 'reply': return <MessageSquare className="text-purple-500" />;
      case 'follow': return <UserPlus className="text-green-500" />;
      case 'publish': return <Award className="text-yellow-500" />;
      default: return <Bell className="text-horror-red" />;
    }
  };

  const getMessage = (n: any) => {
    switch (n.type) {
      case 'comment': return `${n.actorName} আপনার গল্পে মন্তব্য করেছেন।`;
      case 'reply': return `${n.actorName} আপনার মন্তব্যে উত্তর দিয়েছেন।`;
      case 'follow': return `${n.actorName} আপনাকে অনুসরণ করা শুরু করেছেন।`;
      case 'publish': return `আপনার নতুন গল্প প্রকাশিত হয়েছে!`;
      default: return `নতুন নোটিফিকেশন।`;
    }
  };

  if (loading) return <div className="text-center py-20 grayscale opacity-50"><Ghost className="mx-auto mb-4 animate-bounce" /> নোটিফিকেশন লোড হচ্ছে...</div>;

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <div className="flex items-center justify-between mb-8 border-b border-horror-gray pb-4">
        <h1 className="horror-title text-2xl uppercase tracking-widest flex items-center gap-3">
          <Bell className="text-horror-red" /> বিজ্ঞপ্তিসমূহ
        </h1>
        <button onClick={markAllRead} className="text-[10px] uppercase text-gray-500 hover:text-horror-red transition-all">সবগুলো দেখা হয়েছে</button>
      </div>

      <div className="space-y-4">
        {notifications.map((n) => (
          <Link 
            key={n.id} 
            to={n.resourceId ? `/stories/${n.resourceId}` : `/profile/${n.actorId}`}
            className={`block horror-card p-4 transition-all ${n.isRead ? 'opacity-60 bg-transparent' : 'bg-horror-red/5 border-horror-red/30'}`}
          >
            <div className="flex items-start gap-4">
              <div className="p-2 bg-horror-black rounded-full">
                {getIcon(n.type)}
              </div>
              <div className="flex-1">
                <p className={`text-sm text-gray-200 ${!n.isRead && 'font-bold'}`}>{getMessage(n)}</p>
                <p className="text-[10px] text-gray-500 mt-1 uppercase tracking-tight">
                  {n.createdAt ? formatDistanceToNow(n.createdAt.toDate()) : ''} ago
                </p>
              </div>
              {!n.isRead && <div className="w-2 h-2 bg-horror-red rounded-full mt-2" />}
            </div>
          </Link>
        ))}
        {notifications.length === 0 && (
          <div className="text-center py-20">
            <Ghost className="w-12 h-12 text-horror-gray mx-auto mb-4 opacity-20" />
            <p className="text-gray-600 italic">"মৌনতা ভর করেছে আকাশে। এখন কোনো নতুন ডাক নেই।"</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Notifications;
