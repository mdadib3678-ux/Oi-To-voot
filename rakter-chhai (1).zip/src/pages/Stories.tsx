import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, where, orderBy, getDocs, limit } from 'firebase/firestore';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Eye, Heart, MessageSquare, Clock, Filter, ChevronRight, User, Search } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const Stories: React.FC = () => {
  const [stories, setStories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  
  const categories = ['All', 'Supernatural', 'Psychological', 'Urban legend', 'Folk horror'];

  useEffect(() => {
    const fetchStories = async () => {
      setLoading(true);
      try {
        const storiesRef = collection(db, 'stories');
        let q = query(storiesRef, where('status', '==', 'published'), orderBy('createdAt', 'desc'));
        
        if (selectedCategory !== 'All') {
          q = query(storiesRef, where('status', '==', 'published'), where('category', '==', selectedCategory), orderBy('createdAt', 'desc'));
        }
        
        const snap = await getDocs(q);
        const data = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
        
        if (searchQuery) {
          const filtered = data.filter(s => 
            s.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
            s.authorName.toLowerCase().includes(searchQuery.toLowerCase())
          );
          setStories(filtered);
        } else {
          setStories(data);
        }
      } catch (error) {
        console.error("Error fetching stories:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchStories();
  }, [selectedCategory, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-12">
        <div>
          <h1 className="horror-title text-4xl md:text-5xl mb-2">গল্প সমূহ</h1>
          <p className="text-gray-500 italic">"অন্ধকারের প্রতিটি পরতে লুকানো শত শত কাহিনী..."</p>
        </div>

        <div className="w-full md:w-96 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none" size={18} />
          <input 
            type="text" 
            placeholder="গল্প বা লেখক খুঁজুন..." 
            className="horror-input pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="flex items-center gap-4 overflow-x-auto pb-2 no-scrollbar">
          <Filter size={18} className="text-horror-red shrink-0" />
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-1.5 rounded-full border border-horror-gray transition-all whitespace-nowrap text-xs font-bold uppercase tracking-widest ${
                selectedCategory === cat 
                  ? 'bg-horror-red border-horror-red text-white' 
                  : 'hover:border-horror-red/50 hover:text-horror-red text-gray-400'
              }`}
            >
              {cat === 'All' ? 'সব গল্প' : cat}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="horror-card h-80 animate-pulse bg-horror-gray/20"></div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {stories.map(story => (
            <StoryCard key={story.id} story={story} />
          ))}
        </div>
      )}

      {!loading && stories.length === 0 && (
        <div className="text-center py-20 bg-horror-black/40 rounded-xl border border-dashed border-horror-gray">
          <Ghost className="w-16 h-16 text-horror-gray mx-auto mb-4 opacity-20" />
          <p className="text-gray-500 italic text-xl">এই বিভাগে কোনো গল্প পাওয়া যায়নি...</p>
        </div>
      )}
    </div>
  );
};

const StoryCard = ({ story }: { story: any }) => (
  <motion.div 
    whileHover={{ y: -5 }}
    className="horror-card group flex flex-col h-full overflow-hidden"
  >
    {story.coverImage && (
      <Link to={`/stories/${story.id}`} className="block relative h-48 overflow-hidden">
        <img 
          src={story.coverImage} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-70 group-hover:opacity-100"
          alt={story.title}
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-horror-charcoal via-transparent to-transparent opacity-60" />
      </Link>
    )}
    <div className="p-5 flex-1 flex flex-col relative">
      {!story.coverImage && (
        <div className="absolute top-3 right-3 px-2 py-0.5 bg-black/80 text-[10px] uppercase tracking-widest text-horror-red border border-horror-red/50 font-bold backdrop-blur-sm">
          {story.category}
        </div>
      )}
      {story.coverImage && (
        <div className="absolute -top-10 right-3 z-10 px-2 py-0.5 bg-black/80 text-[10px] uppercase tracking-widest text-horror-red border border-horror-red/50 font-bold backdrop-blur-sm">
          {story.category}
        </div>
      )}
      <div className="flex items-center gap-2 mb-3">
        <img 
          src={story.authorPhoto || `https://api.dicebear.com/7.x/avataaars/svg?seed=${story.authorId}`} 
          className="w-5 h-5 rounded-full border border-horror-gray"
          alt={story.authorName}
          referrerPolicy="no-referrer"
        />
        <Link to={`/profile/${story.authorId}`} className="text-[10px] text-gray-500 hover:text-horror-red uppercase tracking-wider transition-colors">
          {story.authorName}
        </Link>
      </div>

      <Link to={`/stories/${story.id}`}>
        <h3 className="text-xl font-bold mb-2 group-hover:text-horror-red transition-colors line-clamp-2 leading-tight">
          {story.title}
        </h3>
      </Link>
      <p className="text-xs text-gray-500 line-clamp-3 mb-6 font-serif italic opacity-80">
        {story.excerpt}
      </p>

      <div className="mt-auto pt-4 border-t border-horror-gray/30">
        <div className="flex items-center justify-between mb-3 text-[10px] text-gray-500">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5" title="ভিউ">
              <Eye size={14} className="text-horror-red/70" />
              <span className="font-mono">{story.viewCount || 0}</span>
            </span>
            <span className="flex items-center gap-1.5" title="লাইক">
              <Heart size={14} className="text-horror-red/70 group-hover:scale-110 transition-transform" />
              <span className="font-mono">{story.likeCount || 0}</span>
            </span>
            <span className="flex items-center gap-1.5" title="কমেন্ট">
              <MessageSquare size={14} className="text-horror-red/70" />
              <span className="font-mono">{story.commentCount || 0}</span>
            </span>
          </div>
          <div className="flex items-center gap-1 bg-horror-gray/20 px-2 py-0.5 rounded-full">
            <Clock size={10} />
            <span>{story.createdAt ? formatDistanceToNow(story.createdAt.toDate()) : 'অজানা'}</span>
          </div>
        </div>
        
        <Link to={`/stories/${story.id}`} className="group/btn flex items-center justify-center gap-2 w-full py-2 bg-horror-gray/10 hover:bg-horror-red/20 text-white border border-horror-gray rounded transition-all text-sm font-bold uppercase tracking-widest">
          গল্পটি পড়ুন <ChevronRight size={16} className="group-hover/btn:translate-x-1 transition-transform" />
        </Link>
      </div>
    </div>
  </motion.div>
);

const Ghost = ({ className }: { className?: string }) => (
  <svg 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M12 2a8 8 0 0 0-8 8v12l3-3 3 3 3-3 3 3v-12a8 8 0 0 0-8-8z" />
    <circle cx="9" cy="10" r="1" />
    <circle cx="15" cy="10" r="1" />
  </svg>
);

export default Stories;
