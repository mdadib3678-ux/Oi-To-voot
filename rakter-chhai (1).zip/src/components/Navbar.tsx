import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { Ghost, LogOut, User, Edit3, Bell, Menu, X, Shield, Volume2, VolumeX, Sun, Moon, BookMarked } from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { signOut } from 'firebase/auth';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { useThemeSettings } from '../context/ThemeContext';

export const Navbar: React.FC = () => {
  const { user, profile } = useAuth();
  const { isSoundEnabled, setIsSoundEnabled, brightness, setBrightness } = useThemeSettings();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  React.useEffect(() => {
    if (!user) {
      setUnreadCount(0);
      return;
    }
    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', user.uid),
      where('isRead', '==', false)
    );
    const unsubscribe = onSnapshot(q, (snap) => {
      setUnreadCount(snap.size);
    });
    return () => unsubscribe();
  }, [user]);

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/');
  };

  return (
    <nav className="sticky top-0 z-50 bg-black/80 backdrop-blur-md border-b border-horror-gray px-4 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <Ghost className="w-8 h-8 text-horror-red group-hover:animate-pulse" />
          <span className="horror-title text-2xl text-horror-red uppercase">Rakter Chhai</span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-6">
          <Link to="/stories" className="hover:text-horror-red transition-colors">গল্প সমূহ</Link>
          <Link to="/about" className="hover:text-horror-red transition-colors">আমাদের কথা</Link>
          <Link to="/editor" className="flex items-center gap-1 horror-btn">
            <Edit3 className="w-4 h-4" />
            <span>লিখুন</span>
          </Link>
          
          {(profile?.role === 'admin' || user?.email === 'astbangla2024@gmail.com') && (
            <Link to="/admin" className="flex items-center gap-1 horror-btn border-yellow-500/50 text-yellow-500 hover:bg-yellow-500 hover:text-black">
              <Shield className="w-4 h-4" />
              <span>অ্যাডমিন</span>
            </Link>
          )}
          
          {user ? (
            <div className="flex items-center gap-4">
              {/* Theme Settings */}
              <div className="flex items-center gap-2 mr-2 border-r border-horror-gray pr-4">
                <button 
                  onClick={() => setIsSoundEnabled(!isSoundEnabled)}
                  className="p-2 hover:bg-horror-gray rounded-full transition-all text-gray-400 hover:text-horror-red"
                  title={isSoundEnabled ? "মৌনতা ফেরান" : "অন্ধকারের শব্দ শুনুন"}
                >
                  {isSoundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
                </button>
                <div className="flex items-center gap-2 group relative">
                  <button className="p-2 hover:bg-horror-gray rounded-full transition-all text-gray-400">
                    <Moon size={18} />
                  </button>
                  <div className="absolute top-full right-0 pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                    <div className="bg-horror-charcoal border border-horror-gray p-3 rounded-lg w-32 shadow-2xl">
                      <p className="text-[10px] uppercase text-gray-500 mb-2">উজ্জ্বলতা</p>
                      <input 
                        type="range" 
                        min="20" max="100" 
                        value={brightness} 
                        onChange={(e) => setBrightness(Number(e.target.value))}
                        className="w-full accent-horror-red"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <Link to="/notifications" className="relative p-2 hover:bg-horror-gray rounded-full">
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-horror-red text-[8px] font-bold text-white rounded-full flex items-center justify-center animate-pulse">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </Link>

              <div className="group relative">
                <button className="flex items-center gap-2 p-1 rounded-full border border-horror-gray hover:border-horror-red transition-all">
                  <img 
                    src={profile?.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`} 
                    alt="Profile" 
                    className="w-8 h-8 rounded-full"
                  />
                </button>
                
                <div className="absolute right-0 top-full pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                  <div className="bg-horror-charcoal border border-horror-gray rounded-lg shadow-xl py-2 w-48">
                    <Link to={`/profile/${user.uid}`} className="flex items-center gap-2 px-4 py-2 hover:bg-horror-gray">
                      <User className="w-4 h-4" />
                      <span>প্রোফাইল</span>
                    </Link>
                    <Link to="/reading-list" className="flex items-center gap-2 px-4 py-2 hover:bg-horror-gray">
                      <BookMarked className="w-4 h-4" />
                      <span>পঠন তালিকা</span>
                    </Link>
                    {(profile?.role === 'admin' || user?.email === 'astbangla2024@gmail.com') && (
                      <Link to="/admin" className="flex items-center gap-2 px-4 py-2 hover:bg-horror-gray text-yellow-500">
                        <Shield className="w-4 h-4" />
                        <span>অ্যাডমিন প্যানেল</span>
                      </Link>
                    )}
                    <button onClick={handleLogout} className="w-full flex items-center gap-2 px-4 py-2 hover:bg-horror-gray text-horror-red">
                      <LogOut className="w-4 h-4" />
                      <span>লগআউট</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-4">
              <Link to="/login" className="hover:text-horror-red transition-colors">লগইন</Link>
              <Link to="/signup" className="horror-btn">সাইনআপ</Link>
            </div>
          )}
        </div>

        {/* Mobile Menu Toggle */}
        <button className="md:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden border-t border-horror-gray overflow-hidden"
          >
            <div className="flex flex-col gap-4 p-4 bg-horror-black">
              <Link to="/stories" onClick={() => setIsMenuOpen(false)}>গল্প সমূহ</Link>
              <Link to="/about" onClick={() => setIsMenuOpen(false)}>আমাদের কথা</Link>
              <Link to="/editor" onClick={() => setIsMenuOpen(false)} className="text-horror-red">লিখুন</Link>
              {user ? (
                <>
                  <Link to={`/profile/${user.uid}`} onClick={() => setIsMenuOpen(false)}>প্রোফাইল</Link>
                  <Link to="/reading-list" onClick={() => setIsMenuOpen(false)}>পঠন তালিকা</Link>
                  <Link to="/notifications" onClick={() => setIsMenuOpen(false)} className="flex items-center justify-between">
                    <span>বিজ্ঞপ্তি</span>
                    {unreadCount > 0 && (
                      <span className="bg-horror-red text-[10px] px-2 py-0.5 rounded-full text-white font-bold">
                        {unreadCount} নতুন
                      </span>
                    )}
                  </Link>
                  {(profile?.role === 'admin' || user?.email === 'astbangla2024@gmail.com') && <Link to="/admin" onClick={() => setIsMenuOpen(false)}>অ্যাডমিন প্যানেল</Link>}
                  <button onClick={handleLogout} className="text-left text-horror-red">লগআউট</button>
                </>
              ) : (
                <>
                  <Link to="/login" onClick={() => setIsMenuOpen(false)}>লগইন</Link>
                  <Link to="/signup" onClick={() => setIsMenuOpen(false)} className="text-horror-red">সাইনআপ</Link>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
