import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export const HorrorBackground: React.FC = () => {
  const [timeState, setTimeState] = useState<'day' | 'twilight' | 'night'>('night');

  useEffect(() => {
    const updateTheme = () => {
      const hour = new Date().getHours();
      if (hour >= 6 && hour < 17) setTimeState('day');
      else if (hour >= 17 && hour < 20) setTimeState('twilight');
      else setTimeState('night');
    };

    updateTheme();
    const interval = setInterval(updateTheme, 60000);
    return () => clearInterval(interval);
  }, []);

  const getColors = () => {
    switch (timeState) {
      case 'day': return ['#1a1a1a', '#2c1e1e', '#0d0d0d'];
      case 'twilight': return ['#0d0d0d', '#3a0000', '#1a1a1a'];
      case 'night': return ['#000000', '#1a0000', '#0a0a0a'];
      default: return ['#0d0d0d', '#1a1a1a', '#000000'];
    }
  };

  const colors = getColors();

  return (
    <div className="fixed inset-0 -z-50 overflow-hidden pointer-events-none">
      <motion.div
        animate={{
          background: `radial-gradient(circle at 50% 50%, ${colors[1]} 0%, ${colors[0]} 100%)`
        }}
        transition={{ duration: 5 }}
        className="absolute inset-0"
      />
      
      {/* Fog effect */}
      <div className="absolute inset-0 opacity-20">
        <motion.div
          animate={{ x: [-100, 100], opacity: [0.1, 0.3, 0.1] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-1/4 left-0 w-full h-1/2 bg-gradient-to-r from-transparent via-white/10 to-transparent blur-3xl"
        />
        <motion.div
          animate={{ x: [100, -100], opacity: [0.1, 0.2, 0.1] }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-1/4 left-0 w-full h-1/2 bg-gradient-to-r from-transparent via-white/5 to-transparent blur-3xl"
        />
      </div>
      
      {/* Dust particles */}
      <AnimatePresence>
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ 
              opacity: [0, 0.5, 0],
              scale: [0, 1, 0],
              x: Math.random() * window.innerWidth,
              y: Math.random() * window.innerHeight
            }}
            transition={{
              duration: 5 + Math.random() * 10,
              repeat: Infinity,
              delay: Math.random() * 5
            }}
            className="absolute w-1 h-1 bg-white/20 rounded-full blur-[1px]"
          />
        ))}
      </AnimatePresence>
    </div>
  );
};
