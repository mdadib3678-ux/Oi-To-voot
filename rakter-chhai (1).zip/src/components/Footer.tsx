import React from 'react';
import { Link } from 'react-router-dom';
import { Ghost, Mail, Github, Twitter, Instagram, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="mt-20 border-t border-horror-gray bg-horror-charcoal/50 backdrop-blur-md pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
        <div className="col-span-1 md:col-span-2">
          <Link to="/" className="flex items-center gap-2 mb-4 group">
            <Ghost className="text-horror-red w-8 h-8 group-hover:animate-bounce" />
            <span className="horror-title text-2xl text-white">রক্তের ছাই</span>
          </Link>
          <p className="text-gray-500 text-sm max-w-md italic mb-6">
            অন্ধকারে হারিয়ে যাওয়া গল্পদের এক অভয়ারণ্য। এখানে প্রতিটি শব্দ শিহরণ জাগায়, প্রতিটি কাহিনী রক্তের ছাই থেকে জন্ম নেয়।
          </p>
          <div className="flex items-center gap-4">
            <a href="#" className="p-2 bg-horror-gray/20 rounded-full hover:bg-horror-red/20 transition-all text-gray-400 hover:text-horror-red"><Twitter size={18} /></a>
            <a href="#" className="p-2 bg-horror-gray/20 rounded-full hover:bg-horror-red/20 transition-all text-gray-400 hover:text-horror-red"><Instagram size={18} /></a>
            <a href="#" className="p-2 bg-horror-gray/20 rounded-full hover:bg-horror-red/20 transition-all text-gray-400 hover:text-horror-red"><Github size={18} /></a>
          </div>
        </div>

        <div>
          <h3 className="font-bold text-white mb-6 uppercase tracking-widest text-sm">দ্রুত লিঙ্ক</h3>
          <ul className="space-y-3 text-sm text-gray-500">
            <li><Link to="/stories" className="hover:text-horror-red transition-colors">সব গল্প</Link></li>
            <li><Link to="/about" className="hover:text-horror-red transition-colors">আমাদের সম্পর্কে</Link></li>
            <li><Link to="/faq" className="hover:text-horror-red transition-colors">জিজ্ঞাসাবাদ</Link></li>
            <li><Link to="/contact" className="hover:text-horror-red transition-colors">যোগাযোগ</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="font-bold text-white mb-6 uppercase tracking-widest text-sm">যোগাযোগ</h3>
          <ul className="space-y-4 text-sm text-gray-500">
            <li className="flex items-center gap-3">
              <Mail size={16} className="text-horror-red" />
              <span>astbangla2024@gmail.com</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 pt-8 border-t border-horror-gray/30 flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-[10px] text-gray-600 uppercase tracking-widest font-mono">
          © {new Date().getFullYear()} রক্তের ছাই. সর্বস্বত্ব সংরক্ষিত।
        </p>
        <p className="text-[10px] text-gray-600 flex items-center gap-1 uppercase tracking-widest font-mono">
          অন্ধকারে তৈরি <Heart size={10} className="text-horror-red inline" /> আধারের বন্ধুদের জন্য
        </p>
      </div>
    </footer>
  );
};
