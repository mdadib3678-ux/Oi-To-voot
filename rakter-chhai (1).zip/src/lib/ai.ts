import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });

export const suggestStoryImprovements = async (title: string, content: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a master of Bengali horror literature. 
      Analyze the following story draft and provide specific suggestions for plot improvement, suspense building, and grammar correction. 
      Respond in a supportive but chilling tone.
      
      Title: ${title}
      Content: ${content}`,
      config: {
        systemInstruction: "You are an expert editor for a Bengali horror platform 'Rakter Chhai'.",
      }
    });
    return response.text;
  } catch (error) {
    console.error("AI Error:", error);
    return "The spirits are silent for now... (AI error)";
  }
};

export const getPlotIdeas = async (category: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Suggest 3 chilling plot hooks for a horror story in the category: ${category}. Each hook should be in Bengali and English.`,
    });
    return response.text;
  } catch (error) {
    console.error("AI Error:", error);
    return "No dark inspiration found...";
  }
};
