import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import rateLimit from "express-rate-limit";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Rate limiting for security
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: "Too many requests from this IP, please try again later after 15 minutes",
    standardHeaders: true,
    legacyHeaders: false,
  });

  app.use(limiter);
  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "Rakter Chhai Server is running" });
  });

  // AI Plagiarism check endpoint
  app.post("/api/plagiarism-check", (req, res) => {
    const { content } = req.body;
    if (!content || content.length < 50) {
      return res.status(400).json({ error: "Content is too short for analysis." });
    }
    
    // Detailed simulation of plagiarism check
    const isMockMatch = content.toLowerCase().includes("ancient curse") || content.toLowerCase().includes("dark woods");
    const score = isMockMatch ? 0.75 : 0.05;
    
    res.json({ 
      score, 
      isPlagiarized: score > 0.5,
      message: score > 0.5 ? "সতর্কতা: এই গল্পের কিছু অংশ অন্য লেখার সাথে হুবহু মিলে গেছে!" : "গল্পটি অনন্য এবং মৌলিক হিসেবে চিহ্নিত হয়েছে।",
      timestamp: new Date().toISOString()
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
